<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/**
 * 업데이트 확인·스스로 업데이트, 설치 현황 알리기. XE1 모듈·XE3·WordPress 플러그인과 같은 방식.
 * 공개 저장소(github.com/easyapplabs/boardmoa-gnuboard)의 latest.json 을 읽고, zip 의 SHA-256·전자서명(conf/release-public.pem)을
 * 확인한 뒤 지금 폴더를 data/appapi-backup/ 에 백업하고 덮어쓴다.
 */
class BoardMoa_Updater
{
    const REPO = 'easyapplabs/boardmoa-gnuboard';
    const REGISTRY_URL = 'https://easyapplabs.com/boardmoa/registry.php';

    private static function manifestUrl()
    {
        return 'https://raw.githubusercontent.com/' . self::REPO . '/main/latest.json';
    }

    private static function releaseBase()
    {
        return 'https://raw.githubusercontent.com/' . self::REPO . '/main/';
    }

    public static function pluginDir()
    {
        return rtrim(str_replace('\\', '/', BOARDMOA_DIR), '/') . '/';
    }

    /** 디스크에 적힌 버전 (업데이트 직후에도 맞게) */
    public static function currentVersion()
    {
        $text = (string)@file_get_contents(self::pluginDir() . 'boot.php');
        return preg_match("/define\('BOARDMOA_VERSION', '([0-9.]+)'\)/", $text, $m) ? $m[1] : BOARDMOA_VERSION;
    }

    private static function settingsFile()
    {
        return G5_DATA_PATH . '/appapi-settings.php';
    }

    /** 설정 (data/appapi-settings.php, PHP 로 감싸 웹에서 읽히지 않게) */
    public static function settings()
    {
        $text = (string)@file_get_contents(self::settingsFile());
        $json = preg_replace('/^<\?php exit; \?>\n/', '', $text);
        $data = json_decode($json, true);
        return is_array($data) ? $data : array();
    }

    public static function saveSettings(array $values)
    {
        $data = array_merge(self::settings(), $values);
        return @file_put_contents(self::settingsFile(), "<?php exit; ?>\n" . json_encode($data, JSON_UNESCAPED_UNICODE)) !== false;
    }

    /** 메뉴설정에 없는 게시판을 앱의 '그 밖의 게시판'으로 (기본 켬, 1.1.12~) */
    public static function otherBoards()
    {
        $s = self::settings();
        return !isset($s['other_boards']) || $s['other_boards'] !== 'N';
    }

    /** 그 가운데 앱에 보이지 않을 게시판 (관리 화면에서 고름, 1.1.17~) */
    public static function otherHidden()
    {
        $s = self::settings();
        return isset($s['other_hidden']) && is_array($s['other_hidden']) ? array_values(array_filter($s['other_hidden'], 'is_string')) : array();
    }

    /** 개발자에게 알리기 (기본 켬) */
    public static function shareSite()
    {
        $s = self::settings();
        return !isset($s['share_site']) || $s['share_site'] !== 'N';
    }

    private static function http($url, $post = null)
    {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, array(CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 60,
                CURLOPT_CONNECTTIMEOUT => 15, CURLOPT_USERAGENT => 'BoardMoa-appapi-gnu'));
            if ($post !== null) {
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            }
            $body = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            return $code === 200 ? (string)$body : false;
        }
        $context = stream_context_create(array('http' => $post !== null
            ? array('method' => 'POST', 'header' => "Content-Type: application/json\r\nUser-Agent: BoardMoa-appapi-gnu\r\n", 'content' => $post, 'timeout' => 60)
            : array('method' => 'GET', 'header' => "User-Agent: BoardMoa-appapi-gnu\r\n", 'timeout' => 60)));
        $body = @file_get_contents($url, false, $context);
        return $body === false ? false : (string)$body;
    }

    /** 설치 현황: 이 사이트 주소를 게시판모아 개발자 서버에 알린다. 실패해도 조용히 넘어간다 */
    public static function report()
    {
        if (!self::shareSite()) {
            return;
        }
        self::http(self::REGISTRY_URL, json_encode(array('url' => rtrim(G5_URL, '/') . '/', 'connector' => 'appapi-gnu', 'version' => self::currentVersion())));
    }

    private static function fetch($url)
    {
        for ($try = 1; $try <= 3; $try++) {
            $body = self::http($url);
            if ($body !== false) {
                return $body;
            }
            if ($try < 3) {
                sleep(1);
            }
        }
        return false;
    }

    private static function manifest()
    {
        $text = self::fetch(self::manifestUrl() . '?t=' . time());
        if ($text === false || $text === '') {
            return BoardMoa_Text::t('업데이트 정보를 받아 오지 못했습니다. 이 서버에서 GitHub(github.com)에 접속할 수 있는지 확인해 주세요.');
        }
        $m = json_decode($text, true);
        if (!is_array($m) || empty($m['version']) || empty($m['zip']) || empty($m['sha256']) || empty($m['signature'])
            || !preg_match('/^[0-9]+(\.[0-9]+){1,3}$/', $m['version']) || !preg_match('#^releases/appapi-gnu-[0-9.]+\.zip$#', $m['zip'])) {
            return BoardMoa_Text::t('업데이트 정보 형식이 올바르지 않습니다.');
        }
        if (!empty($m['min_php']) && version_compare(PHP_VERSION, $m['min_php'], '<')) {
            return BoardMoa_Text::t('새 버전을 쓰려면 PHP {0} 이상이 필요합니다. 이 서버의 PHP는 {1}입니다.', $m['min_php'], PHP_VERSION);
        }
        return $m;
    }

    public static function writable()
    {
        return is_writable(self::pluginDir()) && is_writable(self::pluginDir() . 'lib');
    }

    public static function check()
    {
        self::report();
        $result = array('current' => self::currentVersion(), 'latest' => null, 'notes' => '', 'date' => '', 'has_update' => false,
            'is_newer' => false, 'writable' => self::writable(), 'zip_available' => class_exists('ZipArchive'), 'error' => null);
        $m = self::manifest();
        if (!is_array($m)) {
            $result['error'] = $m;
            return $result;
        }
        $result['latest'] = $m['version'];
        $result['notes'] = isset($m['notes']) ? (string)$m['notes'] : '';
        $result['date'] = isset($m['date']) ? (string)$m['date'] : '';
        $result['has_update'] = version_compare($m['version'], $result['current'], '>');
        $result['is_newer'] = version_compare($result['current'], $m['version'], '>');
        return $result;
    }

    private static function verify($data, $signature)
    {
        $public = @file_get_contents(self::pluginDir() . 'conf/release-public.pem');
        $sig = base64_decode((string)$signature, true);
        return $public && $sig !== false && function_exists('openssl_verify') && openssl_verify($data, $sig, $public, OPENSSL_ALGO_SHA256) === 1;
    }

    public static function update()
    {
        $from = self::currentVersion();
        $fail = function ($message) use ($from) {
            return array('ok' => false, 'message' => $message, 'from' => $from, 'to' => null, 'backup' => null);
        };
        if (!class_exists('ZipArchive')) {
            return $fail(BoardMoa_Text::t('서버의 PHP에 zip 확장 기능(ZipArchive)이 없어서 자동 업데이트를 할 수 없습니다.'));
        }
        if (!self::writable()) {
            return $fail(BoardMoa_Text::t('플러그인 폴더에 쓰기 권한이 없습니다.'));
        }
        $m = self::manifest();
        if (!is_array($m)) {
            return $fail($m);
        }
        if (!version_compare($m['version'], $from, '>')) {
            return array('ok' => true, 'message' => BoardMoa_Text::t('이미 최신 버전입니다.'), 'from' => $from, 'to' => $from, 'backup' => null);
        }
        $zipData = self::fetch(self::releaseBase() . $m['zip']);
        if ($zipData === false || $zipData === '') {
            return $fail(BoardMoa_Text::t('업데이트 파일을 받지 못했습니다.'));
        }
        if (!hash_equals(strtolower($m['sha256']), hash('sha256', $zipData))) {
            return $fail(BoardMoa_Text::t('내려받은 파일이 손상되었습니다(SHA-256 값이 맞지 않음).'));
        }
        if (!self::verify($zipData, $m['signature'])) {
            return $fail(BoardMoa_Text::t('전자서명이 맞지 않아 업데이트하지 않았습니다.'));
        }
        $tmp = G5_DATA_PATH . '/tmp/appapi-update-' . bin2hex(random_bytes(4));
        @mkdir($tmp, 0755, true);
        file_put_contents($tmp . '/package.zip', $zipData);
        $zip = new ZipArchive();
        if ($zip->open($tmp . '/package.zip') !== true) {
            self::removeDir($tmp);
            return $fail(BoardMoa_Text::t('업데이트 파일을 열 수 없습니다.'));
        }
        // zip 안: plugin/appapi/… (모듈 본체)와 extend/appapi.extend.php (관리자 메뉴). 본체만 바꾼다
        // (예전 묶음의 appapi/ 연결 파일도 받는다. 1.0.15 는 extend/ 를 거절했다)
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            $known = strpos($name, 'plugin/appapi/') === 0 || strpos($name, 'appapi/') === 0 || in_array($name, array('plugin/', 'extend/', 'extend/appapi.extend.php'), true);
            if (!$known || strpos($name, '..') !== false || strpos($name, "\0") !== false) {
                $zip->close();
                self::removeDir($tmp);
                return $fail(BoardMoa_Text::t('업데이트 파일 구성이 올바르지 않습니다.'));
            }
        }
        $zip->extractTo($tmp . '/x');
        $zip->close();
        $source = $tmp . '/x/plugin/appapi/';
        if (strpos((string)@file_get_contents($source . 'boot.php'), "define('BOARDMOA_VERSION', '" . $m['version'] . "')") === false) {
            self::removeDir($tmp);
            return $fail(BoardMoa_Text::t('업데이트 파일의 버전이 맞지 않습니다.'));
        }
        $backup = G5_DATA_PATH . '/appapi-backup/' . preg_replace('/[^0-9.]/', '', $from) . '-' . gmdate('YmdHis') . '/';
        if (!@mkdir($backup, 0755, true) || !self::copyDir(self::pluginDir(), $backup)) {
            self::removeDir($tmp);
            return $fail(BoardMoa_Text::t('지금 파일을 백업하지 못해서 업데이트를 중단했습니다.'));
        }
        @file_put_contents(dirname($backup) . '/index.php', "<?php // Silence\n");
        @file_put_contents(dirname($backup) . '/.htaccess', "Require all denied\nDeny from all\n");
        if (!self::copyDir($source, self::pluginDir())) {
            self::copyDir($backup, self::pluginDir());
            self::removeDir($tmp);
            return $fail(BoardMoa_Text::t('새 파일을 쓰는 중에 오류가 나서 이전 버전으로 되돌렸습니다.'));
        }
        self::removeDir($tmp);
        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }
        return array('ok' => true, 'message' => BoardMoa_Text::t('{0} → {1} 업데이트를 마쳤습니다.', $from, $m['version']), 'from' => $from, 'to' => $m['version'], 'backup' => $backup);
    }

    private static function copyDir($from, $to)
    {
        $from = rtrim($from, '/') . '/';
        $to = rtrim($to, '/') . '/';
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($from, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
        foreach ($it as $path => $info) {
            $rel = substr(str_replace('\\', '/', $path), strlen($from));
            if (basename($rel) === '.DS_Store') {
                continue;
            }
            if ($info->isDir()) {
                if (!is_dir($to . $rel) && !@mkdir($to . $rel, 0755, true)) {
                    return false;
                }
            } elseif (!@copy($path, $to . $rel)) {
                return false;
            }
        }
        return true;
    }

    private static function removeDir($dir)
    {
        if (!is_dir($dir)) {
            return;
        }
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($it as $path => $info) {
            $info->isDir() ? @rmdir($path) : @unlink($path);
        }
        @rmdir($dir);
    }
}
