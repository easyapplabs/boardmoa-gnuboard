<?php
if (!defined('_GNUBOARD_')) exit;
// 게시판모아 앱 연동: 관리자 화면 환경설정 메뉴에 '게시판모아' (최고관리자만). 모듈 본체는 plugin/appapi
add_replace('admin_menu', function ($menu) {
    if (is_file(G5_PLUGIN_PATH . '/appapi/admin.php') && isset($menu['menu100'])) {
        $menu['menu100'][] = array('100950', '게시판모아 앱', G5_PLUGIN_URL . '/appapi/admin.php', 'boardmoa', 1);
    }
    return $menu;
}, 10, 1);
