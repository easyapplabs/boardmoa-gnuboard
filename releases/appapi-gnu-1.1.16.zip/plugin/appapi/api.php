<?php
/**
 * 게시판모아 앱 연동 — 앱이 부르는 주소 (<그누보드>/plugin/appapi/api.php?r=<route>).
 * 예전 앱은 연결 파일 <그누보드>/appapi/index.php 로 들어온다.
 * 그누보드(common.php)를 불러오기 전에 쿠키 없는 세션을 걸고(토큰의 회원으로 로그인), 불러온 뒤 요청을 처리한다.
 */
require __DIR__ . '/boot.php';

$boardmoa_root = dirname(dirname(__DIR__));
if (!is_file($boardmoa_root . '/common.php') || !is_file($boardmoa_root . '/bbs/board.php')) {
    header('Content-Type: application/json; charset=utf-8', true, 500);
    echo '{"ok":false,"error":{"code":"server_error","message":"gnuboard not found (plugin/appapi must be in the gnuboard folder)"}}';
    exit;
}
BoardMoa_Api::start();
include_once $boardmoa_root . '/common.php';
BoardMoa_Api::handle();
