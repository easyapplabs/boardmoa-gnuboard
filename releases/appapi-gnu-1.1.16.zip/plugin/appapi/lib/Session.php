<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/**
 * 앱 요청의 세션: 쿠키를 쓰지 않고 파일·DB 에도 남기지 않는 이번 요청만의 세션.
 * common.php 가 session_start 할 때 read() 가 Bearer 토큰의 회원으로 그누보드 로그인 세션 값(ss_mb_id·ss_mb_token_key)을 채운다.
 * 그래서 회원 불러오기·차단·탈퇴 확인·관리자 판단은 common.php 가 웹과 똑같이 한다.
 * 웹 화면이 세션에 넣어 두는 값(글쓰기 토큰 등)은 API 가 이 요청 안에서 넣는다(BoardMoa_Engine).
 */
class BoardMoa_Session implements SessionHandlerInterface
{
    /** 처음 채울 값 (read 가 돌려준다) */
    public static $seed = array();

    public static function install()
    {
        @ini_set('session.use_cookies', '0');
        @ini_set('session.use_only_cookies', '1');
        @ini_set('session.use_trans_sid', '0');
        @ini_set('session.cache_limiter', '');
        session_set_save_handler(new self(), true);
    }

    #[\ReturnTypeWillChange]
    public function open($path, $name)
    {
        return true;
    }

    #[\ReturnTypeWillChange]
    public function close()
    {
        return true;
    }

    #[\ReturnTypeWillChange]
    public function read($id)
    {
        // DB 는 이미 연결돼 있다 (common.php 는 sql_connect 뒤에 session_start)
        BoardMoa_Api::resolveToken();
        return self::encode(self::$seed);
    }

    #[\ReturnTypeWillChange]
    public function write($id, $data)
    {
        return true;
    }

    #[\ReturnTypeWillChange]
    public function destroy($id)
    {
        return true;
    }

    #[\ReturnTypeWillChange]
    public function gc($max)
    {
        return 0;
    }

    /** session.serialize_handler 꼴로 */
    private static function encode(array $data)
    {
        if (!$data) {
            return '';
        }
        $handler = (string)ini_get('session.serialize_handler');
        if ($handler === 'php_serialize') {
            return serialize($data);
        }
        $out = '';
        foreach ($data as $key => $value) {
            if (strpos((string)$key, '|') !== false) {
                continue;
            }
            $out .= $key . '|' . serialize($value);
        }
        return $out;
    }
}
