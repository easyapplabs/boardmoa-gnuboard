<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/**
 * 쓰기 (글·댓글·고치기·지우기·추천·스크랩): 웹의 처리 파일(bbs/write_update.php 등)을 그대로 실행한다 (BoardMoa_Engine).
 * 그래서 쓰기 레벨·그룹 접근·포인트·금지어·도배 방지·첨부 검사·알림 메일·훅이 웹과 같다.
 * 처리 파일이 세션에서 찾는 값(글쓰기 토큰, 고칠 글 표시, 비회원 비밀번호 확인)은 웹 화면(write.php·password_check.php)이 넣는 것과 같게 넣는다.
 */
class BoardMoa_Write
{
    // ---- 사이트·게시판 정보

    public static function features()
    {
        $features = array('html_write', 'guest_write', 'guest_comment', 'guest_manage', 'comment_edit', 'edit_photos', 'extra_vars', 'reply_write', 'unlocked_comment', 'password_throttle', 'file_upload');
        if (self::captchaWidget()) {
            $features[] = 'captcha_solve';
        }
        return $features;
    }

    /**
     * 앱이 풀 수 있는 CAPTCHA (그누보드 설정 '캡챠 선택').
     * reCAPTCHA v2 → 위젯(앱이 웹뷰로 풀어 g-recaptcha-response), 기본 숫자 캡챠(kcaptcha) → 그림(type image: 앱이 image_url 로 그림을 받아 사람이 읽은 숫자를 '번호:답' 으로 보낸다).
     * 보이지 않는 reCAPTCHA 는 null → 앱은 웹으로 안내
     */
    public static function captchaWidget()
    {
        global $config;
        $kind = !empty($config['cf_captcha']) ? (string)$config['cf_captcha'] : 'kcaptcha';
        if ($kind === 'recaptcha' && !empty($config['cf_recaptcha_site_key'])) {
            return array('type' => 'recaptcha', 'site_key' => (string)$config['cf_recaptcha_site_key'], 'theme' => 'auto', 'size' => 'normal');
        }
        if ($kind === 'kcaptcha' && BoardMoa_Write::appSolvesImage() && is_file(G5_PLUGIN_PATH . '/kcaptcha/kcaptcha_config.php') && function_exists('imagecreatetruecolor')) {
            $length = 6;
            include G5_PLUGIN_PATH . '/kcaptcha/kcaptcha_config.php';
            return array('type' => 'image', 'site_key' => '', 'theme' => 'auto', 'size' => 'normal',
                'image_url' => G5_PLUGIN_URL . '/' . basename(dirname(__DIR__)) . '/api.php?r=captcha.image', 'length' => (int)$length, 'input' => 'number');
        }
        return null;
    }

    /** 그림 캡챠를 풀 줄 아는 앱(2.0.4~)은 X-App-Captcha: image 를 보낸다. 예전 앱에는 그림 위젯을 주지 않는다(예전처럼 웹 안내) */
    public static function appSolvesImage()
    {
        $h = isset($_SERVER['HTTP_X_APP_CAPTCHA']) ? strtolower((string)$_SERVER['HTTP_X_APP_CAPTCHA']) : '';
        return in_array('image', array_map('trim', explode(',', $h)), true) || (isset($_GET['r']) && $_GET['r'] === 'captcha.image');
    }

    private static function captchaFile($id)
    {
        return G5_DATA_PATH . '/cache/appapi-captcha-' . hash('sha256', $id . '|' . (defined('G5_TOKEN_ENCRYPTION_KEY') ? G5_TOKEN_ENCRYPTION_KEY : '')) . '.php';
    }

    /**
     * 숫자 캡챠 그림 (kcaptcha_session.php·kcaptcha_image.php 와 같은 글자·암호화·그림). 웹은 답을 세션에 두는데 앱 요청은 세션이 이어지지 않아
     * 번호별로 data/cache 에 10분 둔다(한 번 쓰면 지움). 답 확인은 쓸 때 그 값을 세션에 넣고 엔진의 chk_captcha 가 한다.
     */
    public static function captchaImage()
    {
        $widget = self::captchaWidget();
        if (!$widget || $widget['type'] !== 'image') {
            throw new BoardMoa_Error(404, 'not_found', '자동등록방지 그림을 쓰지 않는 사이트입니다.');
        }
        // 그림마다 답 파일을 하나씩 만들므로 IP 마다 10분에 30장까지
        self::limit('captcha', 30, '잠시 뒤에 다시 해 주세요.');
        self::hit('captcha');
        include_once G5_PLUGIN_PATH . '/kcaptcha/captcha.lib.php';
        $length = 6;
        $allowed_symbols = '0123456789';
        include G5_PLUGIN_PATH . '/kcaptcha/kcaptcha_config.php';
        while (true) {
            $plain = '';
            for ($i = 0; $i < $length; $i++) {
                $plain .= $allowed_symbols[mt_rand(0, strlen($allowed_symbols) - 1)];
            }
            if (!preg_match('/cp|cb|ck|c6|c9|rn|rm|mm|co|do|cl|db|qp|qb|dp|ww/', $plain)) {
                break;
            }
        }
        $key = function_exists('get_string_encrypt') ? get_string_encrypt(md5(sha1($_SERVER['REMOTE_ADDR'])) . $plain) : $plain;
        foreach ((array)glob(G5_DATA_PATH . '/cache/appapi-captcha-*.php') as $old) {
            if (is_file($old) && filemtime($old) < time() - 600) {
                @unlink($old);
            }
        }
        $id = bin2hex(random_bytes(16));
        @file_put_contents(self::captchaFile($id), '<?php exit; ?>' . $key);
        $captcha = new KCAPTCHA();
        $captcha->setKeyString($plain);
        ob_start();
        $captcha->image();
        $data = ob_get_clean();
        if (function_exists('header_remove')) {
            header_remove('Content-Type');
        }
        $mime = substr($data, 0, 3) === "\xFF\xD8\xFF" ? 'image/jpeg' : (substr($data, 0, 4) === 'GIF8' ? 'image/gif' : 'image/png');
        return array('id' => $id, 'image' => 'data:' . $mime . ';base64,' . base64_encode($data), 'length' => (int)$length, 'input' => 'number');
    }

    /** 앱이 보낸 그림 캡챠 답('번호:답')을 웹 양식처럼: 그 번호의 답을 세션에, 사람이 읽은 글자를 captcha_key 로. 번호가 없거나 지났으면 false */
    public static function captchaAnswer($answer)
    {
        $parts = explode(':', (string)$answer, 2);
        if (count($parts) !== 2 || !preg_match('/^[0-9a-f]{32}$/', $parts[0])) {
            return false;
        }
        $file = self::captchaFile($parts[0]);
        $stored = is_file($file) && filemtime($file) >= time() - 600 ? substr((string)@file_get_contents($file), strlen('<?php exit; ?>')) : '';
        @unlink($file);
        if ($stored === '') {
            return false;
        }
        set_session('ss_captcha_key', $stored);
        set_session('ss_captcha_count', 0);
        BoardMoa_Engine::input(array('captcha_key' => trim($parts[1])));
        return true;
    }

    /** CAPTCHA 답을 엔진이 확인하게 넘긴다 (위젯 종류에 맞게). 넘기지 못하면 false */
    public static function captchaPass($answer, $widget)
    {
        if ($answer === '' || !$widget) {
            return false;
        }
        if ($widget['type'] === 'image') {
            return self::captchaAnswer($answer);
        }
        BoardMoa_Engine::input(array('g-recaptcha-response' => $answer));
        return true;
    }

    /** 글쓰기에 캡챠가 필요한가 (write_update.php: 게시판 '캡챠 사용'(고치기 제외) 또는 비회원, 관리자는 아님) */
    private static function captchaFor($b, $w)
    {
        $admin = BoardMoa_Boards::adminOf($b);
        return $admin === '' && (($b['bo_use_captcha'] && $w !== 'u') || !BoardMoa_Api::member());
    }

    /** 글쓰기의 '링크' 칸 (write.php: 링크 레벨 이상이면 G5_LINK_COUNT 개) → 앱의 추가 항목(url) */
    public static function linkKeys($b, $canWrite)
    {
        $level = BoardMoa_Api::member() ? (int)BoardMoa_Api::member()['mb_level'] : 1;
        if (!$canWrite || $level < (int)$b['bo_link_level']) {
            return array();
        }
        $keys = array();
        $count = defined('G5_LINK_COUNT') ? (int)G5_LINK_COUNT : 2;
        for ($i = 1; $i <= $count; $i++) {
            $keys[] = array('idx' => $i, 'name' => BoardMoa_Text::t('링크 {0}', $i), 'type' => 'url', 'engine_type' => 'link', 'required' => false,
                'options' => array(), 'parts' => array(), 'default' => null, 'desc' => null, 'editable' => true);
        }
        return $keys;
    }

    /** 앱이 보낸 링크 (extra_vars {1: 주소, 2: 주소}). 보내지 않은 칸은 $row 의 원래 값 */
    private static function links($b, array $row = null)
    {
        $raw = BoardMoa_Api::param('extra_vars');
        $values = is_array($raw) ? $raw : (is_string($raw) && $raw !== '' ? json_decode($raw, true) : array());
        $values = is_array($values) ? $values : array();
        $allowed = count(self::linkKeys($b, true)) > 0;
        $out = array();
        $count = defined('G5_LINK_COUNT') ? (int)G5_LINK_COUNT : 2;
        for ($i = 1; $i <= $count; $i++) {
            $old = $row ? (string)$row['wr_link' . $i] : '';
            $out['wr_link' . $i] = ($allowed && array_key_exists((string)$i, $values)) ? trim((string)$values[(string)$i]) : $old;
        }
        return $out;
    }

    private static function uploadInfo($b, $canWrite)
    {
        $level = BoardMoa_Api::member() ? (int)BoardMoa_Api::member()['mb_level'] : 1;
        $allowed = $canWrite && (int)$b['bo_upload_count'] > 0 && $level >= (int)$b['bo_upload_level'];
        $size = $allowed ? (int)$b['bo_upload_size'] : null;
        $count = $allowed ? (int)$b['bo_upload_count'] : null;
        return array('allowed' => $allowed, 'max_file_size' => $size, 'max_total_size' => null, 'max_count' => $count,
            // 사진이 아닌 첨부 (1.0.18~, 기능 file_upload): 같은 첨부 칸(파일 개수는 사진과 함께 센다). 그누보드는 확장자를 가리지 않는다
            'files' => array('allowed' => $allowed, 'max_file_size' => $size, 'max_count' => $count, 'extensions' => null));
    }

    public static function boardInfo($b, array $grant)
    {
        $guest = !BoardMoa_Api::member();
        $captcha = array('document' => $grant['write_document'] && self::captchaFor($b, ''), 'comment' => $grant['write_comment'] && $guest);
        return array(
            'upload' => self::uploadInfo($b, $grant['write_document']),
            'extra_keys' => self::linkKeys($b, $grant['write_document']),
            'captcha' => $captcha,
            'captcha_widget' => ($captcha['document'] || $captcha['comment']) ? self::captchaWidget() : null,
            'guest_fields' => ($guest && $grant['write_document']) ? array('nick_name', 'password') : null,
            'guest_comment_fields' => ($guest && $grant['write_comment']) ? array('nick_name', 'password') : null,
        );
    }

    // ---- 공통

    /** CAPTCHA: 앱이 푼 답이 있으면 웹 양식 이름으로, 없으면 거절 (위젯을 줄 수 있으면 함께) */
    private static function captcha($b, $w, $comment = false)
    {
        $need = $comment ? !BoardMoa_Api::member() : self::captchaFor($b, $w);
        if (!$need) {
            return;
        }
        $answer = (string)BoardMoa_Api::param('captcha_response', '');
        $widget = self::captchaWidget();
        if (!self::captchaPass($answer, $widget)) {
            throw new BoardMoa_Error(403, 'captcha_required', $widget ? '자동등록방지 확인이 필요합니다.' : '이 게시판은 자동등록방지 확인이 필요해 웹에서 써 주세요.', false, array('captcha' => $widget));
        }
    }

    /** 처리 파일 실행. alert 는 알맞은 오류로 */
    private static function run($file)
    {
        BoardMoa_Engine::$captured = array();
        self::floodSeed();
        try {
            $run = BoardMoa_Engine::run(G5_BBS_PATH . '/' . $file);
        } catch (BoardMoa_Alert $e) {
            // 글은 저장되고 첨부만 일부 못 올린 경우 (write_update.php 가 알림 뒤 글로 보낸다)
            if (!empty(BoardMoa_Engine::$captured['wr_id']) && $file === 'write_update.php') {
                self::floodSave();
                return array('redirect' => $e->url, 'output' => '', 'notice' => $e->getMessage());
            }
            throw self::alertError($e->getMessage());
        }
        self::floodSave();
        return $run;
    }

    public static function alertError($text)
    {
        $member = BoardMoa_Api::member();
        if (strpos($text, '비밀번호가 틀') !== false) {
            return new BoardMoa_Error(403, 'wrong_password', $text, true);
        }
        if (strpos($text, '자동등록방지') !== false) {
            return new BoardMoa_Error(403, 'captcha_required', $text, true, array('captcha' => self::captchaWidget()));
        }
        if (preg_match('/권한|로그인 후|접근|자신의|관리하는|높은 권한|회원만/u', $text)) {
            return new BoardMoa_Error($member ? 403 : 401, 'not_permitted', $text, true);
        }
        return new BoardMoa_Error(400, 'write_failed', $text, true);
    }

    /** 도배 방지(cf_delay_sec): 웹은 세션의 마지막 글 시각으로 본다. 앱은 쿠키 세션이 없어 회원(비회원은 IP)별로 기억해 그 값을 넣는다 */
    private static function floodFile()
    {
        $m = BoardMoa_Api::member();
        return G5_DATA_PATH . '/cache/appapi-flood-' . md5(($m ? 'm:' . $m['mb_id'] : 'ip:' . BoardMoa_Api::ip()) . '|' . (defined('G5_TOKEN_ENCRYPTION_KEY') ? G5_TOKEN_ENCRYPTION_KEY : ''));
    }

    private static function floodSeed()
    {
        $time = (int)@file_get_contents(self::floodFile());
        if ($time > 0) {
            $_SESSION['ss_datetime'] = $time;
        }
    }

    private static function floodSave()
    {
        if (!empty($_SESSION['ss_datetime'])) {
            @file_put_contents(self::floodFile(), (string)(int)$_SESSION['ss_datetime']);
        }
    }

    // ---- 비회원 비밀번호 시도 제한 (같은 IP 가 10분 안에 10번 틀리면 잠시 막는다, 모듈 3종과 같다)

    private static function throttleFile($kind = '')
    {
        return G5_DATA_PATH . '/cache/appapi-pw-' . md5(BoardMoa_Api::ip() . '|' . (defined('G5_TOKEN_ENCRYPTION_KEY') ? G5_TOKEN_ENCRYPTION_KEY : '') . ($kind !== '' ? '|' . $kind : ''));
    }

    /** 같은 IP 의 $kind 시도가 10분 안에 $max 번이 넘었으면 429 (로그인 실패·캡챠 그림 등, 1.0.18~) */
    public static function limit($kind, $max, $message)
    {
        if (count(self::attempts($kind)) >= $max) {
            throw new BoardMoa_Error(429, 'too_many_attempts', $message);
        }
    }

    public static function hit($kind)
    {
        $list = self::attempts($kind);
        $list[] = time();
        @file_put_contents(self::throttleFile($kind), json_encode($list));
    }

    private static function attempts($kind = '')
    {
        $file = self::throttleFile($kind);
        $list = is_file($file) ? json_decode((string)@file_get_contents($file), true) : array();
        $now = time();
        return array_values(array_filter(is_array($list) ? $list : array(), function ($t) use ($now) {
            return (int)$t > $now - 600;
        }));
    }

    public static function throttle()
    {
        if (count(self::attempts()) >= 10) {
            throw new BoardMoa_Error(429, 'too_many_attempts', '비밀번호를 여러 번 틀렸습니다. 잠시 뒤에 다시 해 주세요.');
        }
    }

    public static function failed()
    {
        $list = self::attempts();
        $list[] = time();
        @file_put_contents(self::throttleFile(), json_encode($list));
    }

    /** 비회원 글·댓글의 비밀번호 확인 (password_check.php 와 같은 check_password). 회원 글이면 null(비밀번호가 통하지 않는다) */
    private static function guestPassword($row)
    {
        $password = (string)BoardMoa_Api::param('password', '');
        if ($password === '') {
            return false;
        }
        if ($row['mb_id'] !== '') {
            throw new BoardMoa_Error(403, 'not_permitted', '권한이 없습니다.');
        }
        self::throttle();
        if (!check_password(BoardMoa_Engine::escape($password), $row['wr_password'])) {
            self::failed();
            throw new BoardMoa_Error(403, 'wrong_password', '비밀번호가 맞지 않습니다.');
        }
        return true;
    }

    /** 고칠·지울 수 있는 사람: 자기 글·관리자, 또는 비밀번호가 맞는 비회원 글 */
    private static function editable($b, $row, $forDelete = false)
    {
        $admin = BoardMoa_Boards::adminOf($b);
        if (BoardMoa_Boards::isMine($row) || $admin !== '') {
            return 'owner';
        }
        if (!BoardMoa_Api::member() && self::guestPassword($row)) {
            return 'password';
        }
        if (!BoardMoa_Api::member() && $row['mb_id'] === '') {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        throw BoardMoa_Api::denied($forDelete ? '자신의 글이 아니므로 삭제할 수 없습니다.' : '자신의 글이 아니므로 수정할 수 없습니다.');
    }

    /** 앱의 photos[] 를 처리 파일이 받는 bf_file[] 로 (비어 있는 칸부터). 정상 업로드 파일만 */
    /** multipart 의 한 이름(photos·files)으로 온 파일들 */
    private static function posted($field)
    {
        if (empty($_FILES[$field])) {
            return array();
        }
        $f = $_FILES[$field];
        $list = array();
        if (is_array($f['name'])) {
            foreach ($f['name'] as $i => $name) {
                $list[] = array('name' => $name, 'type' => $f['type'][$i], 'tmp_name' => $f['tmp_name'][$i], 'error' => $f['error'][$i], 'size' => $f['size'][$i]);
            }
        } else {
            $list[] = $f;
        }
        return array_values(array_filter($list, function ($x) {
            return (string)$x['name'] !== '';
        }));
    }

    /** 앱 사진(photos[])과 사진이 아닌 첨부(files[], 기능 file_upload)를 웹 글쓰기의 첨부 칸(bf_file)으로. $startSlot 은 비어 있는 첫 칸 */
    private static function photos($b, $startSlot)
    {
        $photos = self::posted('photos');
        $files = self::posted('files');
        $list = array_merge($photos, $files);
        if (!$list) {
            return 0;
        }
        $grant = BoardMoa_Boards::grant($b);
        $info = self::uploadInfo($b, $grant['write_document'] || BoardMoa_Boards::adminOf($b) !== '');
        if (!$info['allowed']) {
            throw new BoardMoa_Error(403, 'upload_not_permitted', $files ? '이 게시판은 파일을 첨부할 수 없습니다.' : '이 게시판에는 사진을 올릴 수 없습니다.');
        }
        if ($startSlot + count($list) > (int)$b['bo_upload_count']) {
            throw $files
                ? new BoardMoa_Error(400, 'upload_failed', BoardMoa_Text::t('이 게시판에는 파일을 {0}개까지 첨부할 수 있습니다.', (int)$b['bo_upload_count']), true)
                : new BoardMoa_Error(400, 'too_many_photos', BoardMoa_Text::t('이 게시판에는 사진을 {0}장까지 올릴 수 있습니다.', (int)$b['bo_upload_count']), true);
        }
        foreach ($files as $x) {
            if ((int)$b['bo_upload_size'] > 0 && (int)$x['size'] > (int)$b['bo_upload_size']) {
                throw new BoardMoa_Error(400, 'upload_failed', BoardMoa_Text::t('{0} 파일이 너무 큽니다.', (string)$x['name']), true);
            }
        }
        $bf = array('name' => array(), 'type' => array(), 'tmp_name' => array(), 'error' => array(), 'size' => array());
        for ($i = 0; $i < $startSlot; $i++) {
            foreach (array_keys($bf) as $k) {
                $bf[$k][] = $k === 'error' ? UPLOAD_ERR_NO_FILE : ($k === 'size' ? 0 : '');
            }
        }
        foreach ($list as $x) {
            if ((int)$x['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($x['tmp_name'])) {
                throw new BoardMoa_Error(400, 'upload_failed', $files ? '파일을 올리지 못했습니다.' : '사진을 올리지 못했습니다.');
            }
            foreach (array_keys($bf) as $k) {
                $bf[$k][] = $x[$k];
            }
        }
        $_FILES['bf_file'] = $bf;
        return count($list);
    }

    private static function content($b)
    {
        // 편집기를 쓰지 않는 게시판에 앱이 일반 글자로 쓰면 웹처럼 글자 글(html 없음)로
        if (!$b['bo_use_dhtml_editor'] && BoardMoa_Api::param('content_format') !== 'html') {
            return array(trim(mb_substr(str_replace(array("\r\n", "\r"), "\n", (string)BoardMoa_Api::param('content', '')), 0, 60000)), '');
        }
        return array(BoardMoa_Html::contentParam(), 'html1');
    }

    private static function caName($b, $default)
    {
        $srl = BoardMoa_Api::param('category_srl');
        if ($srl === null || $srl === '') {
            return $default;
        }
        $cats = array();
        foreach (explode('|', (string)$b['bo_category_list']) as $name) {
            if (trim($name) !== '') {
                $cats[] = trim($name);
            }
        }
        return isset($cats[(int)$srl - 1]) ? $cats[(int)$srl - 1] : '';
    }

    // ---- 글

    public static function write()
    {
        $b = BoardMoa_Boards::find(BoardMoa_Api::param('mid'));
        // 답변글 (parent_srl): 웹의 [답변] 단추·write.php?w=r 과 같은 검사 (글을 읽을 수 있고 답변 레벨·비밀글·공지 규칙)
        $parent = null;
        if (BoardMoa_Api::intParam('parent_srl')) {
            $parent = BoardMoa_Boards::row($b, BoardMoa_Api::intParam('parent_srl'));
            BoardMoa_Boards::context($b, $parent['wr_id']);
            if (!BoardMoa_Boards::canRead($b) || !BoardMoa_Boards::secretOpen($b, $parent) || !BoardMoa_Boards::canReply($b, $parent)) {
                throw BoardMoa_Api::denied('글을 답변할 권한이 없습니다.');
            }
        } else {
            BoardMoa_Boards::context($b);
            $grant = BoardMoa_Boards::grant($b);
            if (!$grant['write_document']) {
                throw BoardMoa_Api::denied('글을 쓸 권한이 없습니다.');
            }
        }
        $member = BoardMoa_Api::member();
        $input = array();
        if (!$member) {
            $name = trim((string)BoardMoa_Api::param('nick_name', ''));
            $password = (string)BoardMoa_Api::param('password', '');
            if ($name === '' || $password === '') {
                throw new BoardMoa_Error(400, 'guest_info_required', '이름과 비밀번호를 입력하세요.');
            }
            $input += array('wr_name' => $name, 'wr_password' => $password, 'wr_email' => (string)BoardMoa_Api::param('email_address', ''), 'wr_homepage' => (string)BoardMoa_Api::param('homepage', ''));
        }
        self::captcha($b, $parent ? 'r' : '');
        list($content, $html) = self::content($b);
        $title = trim((string)BoardMoa_Api::param('title', ''));
        if ($title === '' || trim(strip_tags($content, '<img>')) === '') {
            throw new BoardMoa_Error(400, 'missing_content', '제목과 내용을 입력하세요.');
        }
        self::photos($b, 0);
        $input += array(
            'w' => $parent ? 'r' : '', 'bo_table' => $b['bo_table'], 'wr_id' => $parent ? (int)$parent['wr_id'] : 0, 'token' => get_write_token($b['bo_table']),
            'wr_subject' => $title, 'wr_content' => $content, 'html' => $html,
            'secret' => ((int)$b['bo_use_secret'] > 0 && BoardMoa_Api::boolParam('is_secret')) ? 'secret' : '',
            'ca_name' => self::caName($b, $parent ? (string)$parent['ca_name'] : ''),
        ) + self::links($b);
        if ($parent) {
            // write.php 가 답변 화면에서 넣는 값
            set_session('ss_bo_table', $b['bo_table']);
            set_session('ss_wr_id', (int)$parent['wr_id']);
        }
        BoardMoa_Engine::input($input);
        self::run('write_update.php');
        if (empty(BoardMoa_Engine::$captured['wr_id'])) {
            throw new BoardMoa_Error(400, 'write_failed', '글을 저장하지 못했습니다.');
        }
        return array('document_srl' => (int)BoardMoa_Engine::$captured['wr_id']);
    }

    public static function source()
    {
        $b = BoardMoa_Boards::find(BoardMoa_Api::param('mid'));
        $row = BoardMoa_Boards::row($b, BoardMoa_Api::intParam('document_srl'));
        BoardMoa_Boards::context($b, $row['wr_id']);
        self::editable($b, $row);
        $html = strpos($row['wr_option'], 'html') !== false;
        $grant = BoardMoa_Boards::grant($b);
        $count = sql_fetch(" select count(*) as cnt from {$GLOBALS['g5']['board_file_table']} where bo_table = '{$b['bo_table']}' and wr_id = '" . (int)$row['wr_id'] . "' ");
        $upload = self::uploadInfo($b, true);
        if ($upload['allowed'] && (int)$count['cnt'] >= (int)$b['bo_upload_count']) {
            $upload['allowed'] = false;
            $upload['files']['allowed'] = false;
        }
        $out = array(
            'document_srl' => (int)$row['wr_id'],
            'title' => html_entity_decode((string)$row['wr_subject'], ENT_QUOTES, 'UTF-8'),
            'content' => $html ? (string)$row['wr_content'] : nl2br(htmlspecialchars((string)$row['wr_content'], ENT_QUOTES, 'UTF-8'), false),
            'base_url' => BoardMoa_Html::base() . '/',
            'category_srl' => BoardMoa_Boards::summary($b, $row)['category_srl'],
            'extra_keys' => self::linkKeys($b, true),
            'extra_values' => (object)array_filter(array('1' => (string)$row['wr_link1'], '2' => (string)$row['wr_link2']), 'strlen'),
            'board' => BoardMoa_Boards::info($b, $grant),
            'upload' => $upload,
        );
        if ($grant['manager']) {
            $out['manage'] = array('is_notice' => in_array((string)$row['wr_id'], array_map('trim', explode(',', (string)$b['bo_notice'])), true), 'title_bold' => false, 'title_color' => '');
        }
        return $out;
    }

    public static function update()
    {
        global $g5;
        $b = BoardMoa_Boards::find(BoardMoa_Api::param('mid'));
        $row = BoardMoa_Boards::row($b, BoardMoa_Api::intParam('document_srl'));
        BoardMoa_Boards::context($b, $row['wr_id']);
        $how = self::editable($b, $row);
        self::captcha($b, 'u');
        $title = trim((string)BoardMoa_Api::param('title', ''));
        $content = BoardMoa_Html::fromEditor((string)BoardMoa_Api::param('content', ''));
        if ($title === '' || $content === '') {
            throw new BoardMoa_Error(400, 'missing_content', '제목과 내용을 입력하세요.');
        }
        $files = sql_fetch(" select max(bf_no) as last, count(*) as cnt from {$g5['board_file_table']} where bo_table = '{$b['bo_table']}' and wr_id = '" . (int)$row['wr_id'] . "' ");
        self::photos($b, $files['cnt'] ? (int)$files['last'] + 1 : 0);
        $options = (string)$row['wr_option'];
        $secret = strpos($options, 'secret') !== false ? 'secret' : '';
        if (BoardMoa_Api::param('is_secret') !== null && (int)$b['bo_use_secret'] > 0) {
            $secret = BoardMoa_Api::boolParam('is_secret') ? 'secret' : '';
        }
        $grant = BoardMoa_Boards::grant($b);
        $isNotice = in_array((string)$row['wr_id'], array_map('trim', explode(',', (string)$b['bo_notice'])), true);
        if ($grant['manager'] && BoardMoa_Api::param('is_notice') !== null) {
            $isNotice = in_array(strtoupper((string)BoardMoa_Api::param('is_notice')), array('Y', '1', 'TRUE'), true);
        }
        // 웹 고치기 양식처럼 앱이 보내지 않는 칸은 원래 값 (링크·여분 필드·메일 받기·작성자)
        $input = array(
            'w' => 'u', 'bo_table' => $b['bo_table'], 'wr_id' => (int)$row['wr_id'], 'token' => get_write_token($b['bo_table']),
            'wr_subject' => $title, 'wr_content' => $content, 'html' => 'html1', 'secret' => $secret,
            'mail' => strpos($options, 'mail') !== false ? 'mail' : '',
            'notice' => ($grant['manager'] && $isNotice) ? '1' : '',
            'ca_name' => self::caName($b, (string)$row['ca_name']),
        ) + self::links($b, $row);
        for ($i = 1; $i <= 10; $i++) {
            $input['wr_' . $i] = (string)$row['wr_' . $i];
        }
        if ($row['mb_id'] === '') {
            $input += array('wr_name' => (string)$row['wr_name'], 'wr_email' => (string)$row['wr_email'], 'wr_homepage' => (string)$row['wr_homepage'], 'wr_password' => '');
        }
        // 웹 고치기 화면(write.php)이 세션에 넣는 값: 고칠 글 표시, 비회원 글은 비밀번호 확인
        set_session('ss_bo_table', $b['bo_table']);
        set_session('ss_wr_id', (int)$row['wr_id']);
        if ($how === 'password') {
            g5_grant_write_edit_auth($b['bo_table'], $row);
        }
        BoardMoa_Engine::input($input);
        self::run('write_update.php');
        return array('document_srl' => (int)$row['wr_id']);
    }

    public static function delete()
    {
        global $g5;
        $b = BoardMoa_Boards::find(BoardMoa_Api::param('mid'));
        $row = BoardMoa_Boards::row($b, BoardMoa_Api::intParam('document_srl'));
        BoardMoa_Boards::context($b, $row['wr_id']);
        self::editable($b, $row, true);
        $token = get_random_token_string(16);
        set_session('ss_delete_token', $token);
        BoardMoa_Engine::input(array('bo_table' => $b['bo_table'], 'wr_id' => (int)$row['wr_id'], 'token' => $token, 'wr_password' => (string)BoardMoa_Api::param('password', '')));
        self::run('delete.php');
        $left = sql_fetch(" select wr_id from `{$g5['write_prefix']}{$b['bo_table']}` where wr_id = '" . (int)$row['wr_id'] . "' ");
        if (!empty($left['wr_id'])) {
            throw new BoardMoa_Error(400, 'delete_failed', '글을 지우지 못했습니다.');
        }
        return array('deleted' => true);
    }

    // ---- 댓글

    private static function commentRow($b, $commentSrl)
    {
        global $g5;
        $c = sql_fetch(" select * from `{$g5['write_prefix']}{$b['bo_table']}` where wr_id = '" . (int)$commentSrl . "' ");
        if (empty($c['wr_id']) || (int)$c['wr_is_comment'] !== 1) {
            throw new BoardMoa_Error(404, 'comment_not_found', '없는 댓글입니다.');
        }
        return $c;
    }

    /** 글을 읽을 수 있어야 댓글을 쓰고 고친다 (웹은 글 화면에서만 댓글 양식이 보인다) */
    private static function readableDoc($b, $wrId)
    {
        $row = BoardMoa_Boards::row($b, $wrId);
        BoardMoa_Boards::context($b, $row['wr_id']);
        if (!BoardMoa_Boards::canRead($b)) {
            throw BoardMoa_Api::denied('글을 읽을 권한이 없습니다.');
        }
        if (!BoardMoa_Boards::secretOpen($b, $row)) {
            // 비밀번호로 연 비회원 비밀글 (기능 unlocked_comment): 글 응답의 comment_document_password 가 참이면 앱이 연 비밀번호를 같이 보낸다
            $password = (string)BoardMoa_Api::param('document_password', '');
            if ($password === '' || $row['mb_id'] !== '') {
                throw BoardMoa_Api::denied('비밀글입니다.');
            }
            self::throttle();
            if (!check_password(BoardMoa_Engine::escape($password), $row['wr_password'])) {
                self::failed();
                throw new BoardMoa_Error(403, 'wrong_password', '비밀번호가 맞지 않습니다.');
            }
        }
        return $row;
    }

    public static function commentWrite()
    {
        $b = BoardMoa_Boards::find(BoardMoa_Api::param('mid'));
        $row = self::readableDoc($b, BoardMoa_Api::intParam('document_srl'));
        $member = BoardMoa_Api::member();
        $input = array();
        if (!$member) {
            $name = trim((string)BoardMoa_Api::param('nick_name', ''));
            $password = (string)BoardMoa_Api::param('password', '');
            if ($name === '' && $password === '') {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            if ($name === '' || $password === '') {
                throw new BoardMoa_Error(400, 'guest_info_required', '이름과 비밀번호를 입력하세요.');
            }
            $input += array('wr_name' => $name, 'wr_password' => $password, 'wr_email' => (string)BoardMoa_Api::param('email_address', ''), 'wr_homepage' => (string)BoardMoa_Api::param('homepage', ''));
        }
        if (BoardMoa_Api::member() ? (int)$member['mb_level'] < (int)$b['bo_comment_level'] : (int)$b['bo_comment_level'] > 1) {
            throw BoardMoa_Api::denied('댓글을 쓸 권한이 없습니다.');
        }
        self::captcha($b, 'c', true);
        $content = trim(mb_substr(str_replace(array("\r\n", "\r"), "\n", (string)BoardMoa_Api::param('content', '')), 0, 10000));
        if ($content === '') {
            throw new BoardMoa_Error(400, 'missing_content', '내용을 입력하세요.');
        }
        $parent = BoardMoa_Api::intParam('parent_srl');
        if ($parent) {
            $p = self::commentRow($b, $parent);
            if ((int)$p['wr_parent'] !== (int)$row['wr_id']) {
                throw new BoardMoa_Error(404, 'comment_not_found', '없는 댓글입니다.');
            }
        }
        $token = get_random_token_string(16);
        set_session('ss_comment_token', $token);
        $input += array('w' => 'c', 'bo_table' => $b['bo_table'], 'wr_id' => (int)$row['wr_id'], 'comment_id' => $parent ?: '', 'token' => $token,
            'wr_content' => $content, 'wr_secret' => BoardMoa_Api::boolParam('is_secret') ? 'secret' : '');
        BoardMoa_Engine::input($input);
        self::run('write_comment_update.php');
        if (empty(BoardMoa_Engine::$captured['comment_id'])) {
            throw new BoardMoa_Error(400, 'write_failed', '댓글을 저장하지 못했습니다.');
        }
        return array('comment_srl' => (int)BoardMoa_Engine::$captured['comment_id'], 'document_srl' => (int)$row['wr_id'], 'pending' => false);
    }

    public static function commentUpdate()
    {
        $b = BoardMoa_Boards::find(BoardMoa_Api::param('mid'));
        $c = self::commentRow($b, BoardMoa_Api::intParam('comment_srl'));
        $row = self::readableDoc($b, (int)$c['wr_parent']);
        $member = BoardMoa_Api::member();
        $input = array();
        if (!$member) {
            if (!self::guestPassword($c)) {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            $input += array('wr_name' => (string)$c['wr_name'], 'wr_password' => (string)BoardMoa_Api::param('password', ''));
        }
        self::captcha($b, 'cu', true);
        $content = trim(mb_substr(str_replace(array("\r\n", "\r"), "\n", (string)BoardMoa_Api::param('content', '')), 0, 10000));
        if ($content === '') {
            throw new BoardMoa_Error(400, 'missing_content', '내용을 입력하세요.');
        }
        $token = get_random_token_string(16);
        set_session('ss_comment_token', $token);
        $input += array('w' => 'cu', 'bo_table' => $b['bo_table'], 'wr_id' => (int)$row['wr_id'], 'comment_id' => (int)$c['wr_id'], 'token' => $token,
            'wr_content' => $content, 'wr_secret' => strpos((string)$c['wr_option'], 'secret') !== false ? 'secret' : '');
        BoardMoa_Engine::input($input);
        self::run('write_comment_update.php');
        return array('comment_srl' => (int)$c['wr_id'], 'document_srl' => (int)$row['wr_id']);
    }

    public static function commentDelete()
    {
        global $g5;
        $b = BoardMoa_Boards::find(BoardMoa_Api::param('mid'));
        $c = self::commentRow($b, BoardMoa_Api::intParam('comment_srl'));
        BoardMoa_Boards::context($b, (int)$c['wr_parent']);
        if (!BoardMoa_Api::member() && (string)BoardMoa_Api::param('password', '') === '') {
            throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
        }
        if (!BoardMoa_Api::member()) {
            self::guestPassword($c);
        }
        $token = get_random_token_string(16);
        set_session('ss_delete_comment_' . (int)$c['wr_id'] . '_token', $token);
        BoardMoa_Engine::input(array('bo_table' => $b['bo_table'], 'comment_id' => (int)$c['wr_id'], 'token' => $token, 'wr_password' => (string)BoardMoa_Api::param('password', '')));
        self::run('delete_comment.php');
        $left = sql_fetch(" select wr_id from `{$g5['write_prefix']}{$b['bo_table']}` where wr_id = '" . (int)$c['wr_id'] . "' ");
        if (!empty($left['wr_id'])) {
            throw new BoardMoa_Error(400, 'delete_failed', '댓글을 지우지 못했습니다.');
        }
        return array('deleted' => true);
    }

    // ---- 추천·스크랩 (회원만, 웹과 같은 good.php·scrap_popin_update.php)

    public static function vote()
    {
        global $g5;
        $b = BoardMoa_Boards::find(BoardMoa_Api::param('mid'));
        $row = self::readableDoc($b, BoardMoa_Api::intParam('document_srl'));
        BoardMoa_Boards::chargeRead($b, $row);
        $member = BoardMoa_Api::member();
        if (BoardMoa_Api::boolParam('cancel')) {
            throw new BoardMoa_Error(400, 'vote_failed', '추천은 취소할 수 없습니다.');
        }
        $good = BoardMoa_Api::intParam('point', 1) < 0 ? 'nogood' : 'good';
        // good.php 는 글을 읽은 세션에서만 받는다(ss_view_…): 위에서 같은 읽기 권한을 확인했다
        set_session('ss_view_' . $b['bo_table'] . '_' . $row['wr_id'], true);
        BoardMoa_Engine::input(array('bo_table' => $b['bo_table'], 'wr_id' => (int)$row['wr_id'], 'good' => $good), true);
        $message = '';
        try {
            self::run('good.php');
        } catch (BoardMoa_Error $e) {
            $message = $e->getMessage();
        }
        $mine = sql_fetch(" select bg_flag from {$g5['board_good_table']} where bo_table = '{$b['bo_table']}' and wr_id = '" . (int)$row['wr_id'] . "' and mb_id = '" . sql_real_escape_string($member['mb_id']) . "' ");
        // good.php 는 성공해도 '…하셨습니다' 알림으로 끝난다: 내 추천이 남았는지로 가린다
        if (empty($mine['bg_flag']) || $mine['bg_flag'] !== $good || strpos($message, '이미') !== false || strpos($message, '자신의') !== false || strpos($message, '사용하지') !== false) {
            if ($message === '' || strpos($message, '하셨습니다') !== false) {
                $message = BoardMoa_Text::t('추천하지 못했습니다.');
            }
            throw new BoardMoa_Error(400, 'vote_failed', $message, true);
        }
        $fresh = BoardMoa_Boards::row($b, $row['wr_id']);
        return array(
            'vote_up' => array('enabled' => (bool)$b['bo_use_good'], 'count' => (int)$fresh['wr_good'], 'public' => false),
            'vote_down' => array('enabled' => (bool)$b['bo_use_nogood'], 'count' => (int)$fresh['wr_nogood'], 'public' => false),
            'my_vote' => $good === 'good' ? 1 : -1,
            'can_cancel_vote' => false,
            'is_mine' => false,
            'can_scrap' => true,
            'can_declare' => false,
        );
    }

    public static function scrap()
    {
        global $g5;
        $b = BoardMoa_Boards::find(BoardMoa_Api::param('mid'));
        $row = self::readableDoc($b, BoardMoa_Api::intParam('document_srl'));
        $member = BoardMoa_Api::member();
        $where = " where mb_id = '" . sql_real_escape_string($member['mb_id']) . "' and bo_table = '{$b['bo_table']}' and wr_id = '" . (int)$row['wr_id'] . "' ";
        $had = sql_fetch(" select count(*) as cnt from {$g5['scrap_table']} $where ");
        if (!empty($had['cnt'])) {
            throw new BoardMoa_Error(400, 'already_scrapped', '이미 스크랩하신 글입니다.');
        }
        BoardMoa_Engine::input(array('bo_table' => $b['bo_table'], 'wr_id' => (int)$row['wr_id']), true);
        self::run('scrap_popin_update.php');
        $now = sql_fetch(" select count(*) as cnt from {$g5['scrap_table']} $where ");
        if (empty($now['cnt'])) {
            throw new BoardMoa_Error(400, 'scrap_failed', '스크랩하지 못했습니다.');
        }
        return array('scrapped' => true);
    }
}
