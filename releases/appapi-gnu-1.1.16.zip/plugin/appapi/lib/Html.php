<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/** 주소·시각·본문 HTML 도우미 */
class BoardMoa_Html
{
    /** 사이트 주소 (끝 / 없음, 그누보드 G5_URL) */
    public static function base()
    {
        return rtrim(G5_URL, '/');
    }

    public static function origin()
    {
        $p = parse_url(G5_URL);
        return $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
    }

    public static function absolute($url)
    {
        $url = trim(html_entity_decode((string)$url, ENT_QUOTES, 'UTF-8'));
        if ($url === '' || preg_match('#^[a-z][a-z0-9+.\-]*:#i', $url)) {
            return $url;
        }
        if (strpos($url, '//') === 0) {
            return (strpos(G5_URL, 'https:') === 0 ? 'https:' : 'http:') . $url;
        }
        if ($url[0] === '/') {
            return self::origin() . $url;
        }
        if ($url[0] === '#' || $url[0] === '?') {
            return $url;
        }
        return self::base() . '/' . ltrim($url, './');
    }

    /** 'Y-m-d H:i:s' (사이트 시간, 그누보드는 PHP 기본 시간대로 저장) → ISO 8601 */
    public static function iso($local)
    {
        $local = (string)$local;
        if ($local === '' || strpos($local, '0000') === 0) {
            return null;
        }
        $time = strtotime($local);
        return $time ? date('c', $time) : null;
    }

    public static function timestamp($local)
    {
        $time = strtotime((string)$local);
        return $time ? $time : 0;
    }

    /** 제목 등: 태그를 빼고 HTML 엔티티를 푼다 */
    public static function text($html)
    {
        return trim(html_entity_decode(strip_tags((string)$html), ENT_QUOTES, 'UTF-8'));
    }

    /** 목록 요약: 본문 글자 120자 */
    public static function summary($html, $length = 120)
    {
        $html = preg_replace('#<(script|style)\b.*?</\1>#is', '', (string)$html);
        $html = preg_replace('/<!--.*?-->/s', '', $html);
        $html = preg_replace('#<br\s*/?>|</p>|</div>#i', ' ', $html);
        $text = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($html), ENT_QUOTES, 'UTF-8')));
        return mb_substr($text, 0, $length);
    }

    /** 본문 속 첫 그림 */
    public static function firstImage($html)
    {
        if (preg_match('/<img[^>]+src=["\']([^"\']+)["\']/i', (string)$html, $m)) {
            return self::absolute($m[1]);
        }
        return null;
    }

    /** 앱은 일반 글자로 보낸다: 태그는 글자로, 줄바꿈은 살린다 (그누보드 html1 글로 저장) */
    public static function fromText($text)
    {
        $text = trim(str_replace(array("\r\n", "\r"), "\n", (string)$text));
        if ($text === '') {
            return '';
        }
        $out = array();
        foreach (preg_split("/\n{2,}/", mb_substr($text, 0, 50000)) as $para) {
            $out[] = '<p>' . nl2br(htmlspecialchars($para, ENT_QUOTES, 'UTF-8'), false) . '</p>';
        }
        return implode("\n", $out);
    }

    /** 앱 꾸밈 편집기의 HTML. 글자·사진이 없으면 빈 본문 */
    public static function fromEditor($html)
    {
        $html = trim((string)$html);
        if (trim(str_replace(array('&nbsp;', "\xC2\xA0"), ' ', strip_tags($html, '<img><video><iframe>'))) === '') {
            return '';
        }
        return mb_substr($html, 0, 500000);
    }

    public static function contentParam()
    {
        $content = (string)BoardMoa_Api::param('content', '');
        return BoardMoa_Api::param('content_format') === 'html' ? self::fromEditor($content) : self::fromText($content);
    }

    /**
     * 앱에 보낼 본문 HTML: 상대 주소를 절대 주소로, 스크립트를 빼고,
     * 같은 사이트의 게시판·글 링크에는 ?mid=…&document_srl=… 를 붙인다 (앱이 글 화면으로 연다. 웹은 모르는 값을 무시한다).
     */
    public static function content($html)
    {
        $html = (string)$html;
        $html = preg_replace('#<script\b[^>]*>.*?</script>#is', '', $html);
        $html = preg_replace('/<!--.*?-->/s', '', $html);
        $html = preg_replace_callback('/\b(src|href|poster)\s*=\s*(["\'])(.*?)\2/i', function ($m) {
            $url = $m[3];
            if ($url === '' || $url[0] === '#' || stripos($url, 'javascript:') === 0 || stripos($url, 'data:') === 0) {
                return $m[0];
            }
            $abs = BoardMoa_Html::absolute($url);
            if (strtolower($m[1]) === 'href') {
                $abs = BoardMoa_Html::appLink($abs);
            }
            return $m[1] . '=' . $m[2] . htmlspecialchars($abs, ENT_QUOTES, 'UTF-8') . $m[2];
        }, $html);
        return trim($html);
    }

    /** 같은 사이트 링크면 앱이 알아보는 mid·document_srl 를 붙인다 */
    public static function appLink($url)
    {
        $host = strtolower((string)parse_url($url, PHP_URL_HOST));
        if ($host === '' || $host !== strtolower((string)parse_url(G5_URL, PHP_URL_HOST))) {
            return $url;
        }
        $query = (string)parse_url($url, PHP_URL_QUERY);
        if (strpos($query, 'document_srl=') !== false || preg_match('/(^|&)mid=/', $query)) {
            return $url;
        }
        $found = BoardMoa_Boards::locate($url);
        if (!$found) {
            return $url;
        }
        $add = array('mid' => $found['mid']);
        if (!empty($found['document_srl'])) {
            $add['document_srl'] = $found['document_srl'];
        }
        $fragment = '';
        if (($pos = strpos($url, '#')) !== false) {
            $fragment = substr($url, $pos);
            $url = substr($url, 0, $pos);
        }
        return $url . (strpos($url, '?') === false ? '?' : '&') . http_build_query($add) . $fragment;
    }
}
