<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/**
 * 요청 입구: ?r=<route> 를 처리하고 {"ok", "data"|"error"} 로 답한다 (docs/API.md).
 * 앱은 쿠키를 쓰지 않는다: Bearer 토큰의 회원을 그누보드 로그인 세션 값으로 넣어(BoardMoa_Session) common.php 가 웹처럼 회원을 불러온다.
 */
class BoardMoa_Api
{
    const VERSION = BOARDMOA_VERSION;

    /** route => [메서드, 로그인 필요(true)/선택(false)/토큰 안 봄(null), 처리] */
    private static function routes()
    {
        return array(
            'site' => array('GET', false, array('BoardMoa_Boards', 'site')),
            'menu' => array('GET', false, array('BoardMoa_Boards', 'menu')),
            'auth.login' => array('POST', null, array(__CLASS__, 'login')),
            'auth.refresh' => array('POST', null, array(__CLASS__, 'refresh')),
            'auth.logout' => array('POST', null, array(__CLASS__, 'logout')),
            // 로그인한 기기 (1.0.19~, 기능 devices): 이 회원의 앱 로그인(토큰)마다 한 줄, 줄마다 로그아웃
            'auth.devices' => array('GET', true, array(__CLASS__, 'devices')),
            'auth.devices.revoke' => array('POST', true, array(__CLASS__, 'revokeDevice')),
            'me' => array('GET', true, array(__CLASS__, 'me')),
            'feed' => array('GET', false, array('BoardMoa_Boards', 'feed')),
            'board' => array('GET', false, array('BoardMoa_Boards', 'board')),
            // POST 도 받는다: 비회원 비밀글을 비밀번호(password)로 열 때 주소에 남기지 않으려고
            'document' => array('GET|POST', false, array('BoardMoa_Boards', 'document')),
            'comments' => array('GET', false, array('BoardMoa_Boards', 'comments')),
            'page' => array('GET', false, array('BoardMoa_Boards', 'page')),
            'resolve' => array('GET', false, array('BoardMoa_Boards', 'resolve')),
            'file' => array('GET', false, array('BoardMoa_Boards', 'file')),
            'captcha.image' => array('GET', false, array('BoardMoa_Write', 'captchaImage')),
            'document.write' => array('POST', false, array('BoardMoa_Write', 'write')),
            'document.source' => array('GET|POST', false, array('BoardMoa_Write', 'source')),
            'document.update' => array('POST', false, array('BoardMoa_Write', 'update')),
            'document.delete' => array('POST', false, array('BoardMoa_Write', 'delete')),
            'comment.write' => array('POST', false, array('BoardMoa_Write', 'commentWrite')),
            'comment.update' => array('POST', false, array('BoardMoa_Write', 'commentUpdate')),
            'comment.delete' => array('POST', false, array('BoardMoa_Write', 'commentDelete')),
            'document.vote' => array('POST', true, array('BoardMoa_Write', 'vote')),
            'document.scrap' => array('POST', true, array('BoardMoa_Write', 'scrap')),
            'my.menu' => array('GET', true, array('BoardMoa_My', 'menu')),
            'my.documents' => array('GET', true, array('BoardMoa_My', 'documents')),
            'my.comments' => array('GET', true, array('BoardMoa_My', 'comments')),
            'my.scraps' => array('GET', true, array('BoardMoa_My', 'scraps')),
            'my.scrap.delete' => array('POST', true, array('BoardMoa_My', 'scrapDelete')),
            'my.messages' => array('GET', true, array('BoardMoa_My', 'messages')),
            'my.message' => array('GET', true, array('BoardMoa_My', 'message')),
            'my.message.delete' => array('POST', true, array('BoardMoa_My', 'messageDelete')),
            'message.send' => array('POST', true, array('BoardMoa_My', 'messageSend')),
            'member.menu' => array('GET', false, array('BoardMoa_My', 'memberMenu')),
            'member.info' => array('GET', true, array('BoardMoa_My', 'memberInfo')),
            // 가입 (1.0.28~): 웹 가입 처리 파일 그대로 (BoardMoa_Signup)
            'signup.form' => array('GET', false, array('BoardMoa_Signup', 'form')),
            'signup' => array('POST', null, array('BoardMoa_Signup', 'signup')),
            // 내 정보 수정 (1.0.20~): 웹 회원정보 수정 처리 파일(register_form_update.php)을 그대로. 탈퇴는 웹 화면에서
            'me.form' => array('GET', true, array('BoardMoa_Me', 'form')),
            'me.update' => array('POST', true, array('BoardMoa_Me', 'update')),
            'me.password' => array('POST', true, array('BoardMoa_Me', 'password')),
            'me.image' => array('POST', true, array('BoardMoa_Me', 'image')),
            'me.leave' => array('POST', true, array('BoardMoa_My', 'webOnly')),
            // 알림 기능이 없는 엔진: 앱이 종 아이콘을 숨긴다
            'notify.count' => array('GET', true, array(__CLASS__, 'noNotify')),
        );
    }

    /** @var array|null 앱이 보낸 값 (common.php 가 이스케이프하기 전 원래 값 + JSON 본문) */
    private static $input = null;
    /** @var array|null 이번 요청의 토큰 행 */
    public static $token = null;
    private static $tokenMember = '';
    private static $authError = null;
    private static $responded = false;

    // ---- 시작 (common.php 를 부르기 전)

    /** api.php 가 common.php 앞에서 부른다: 입력을 받아 두고, 쿠키 없는 세션·종료 처리를 건다 */
    public static function start()
    {
        define('BOARDMOA_DOING_API', true);
        $input = $_GET;
        $type = strtolower(isset($_SERVER['CONTENT_TYPE']) ? (string)$_SERVER['CONTENT_TYPE'] : '');
        if (strpos($type, 'application/json') !== false) {
            $json = json_decode((string)file_get_contents('php://input'), true);
            if (is_array($json)) {
                $input = array_merge($input, $json);
            }
        } else {
            $input = array_merge($input, $_POST);
        }
        self::$input = $input;
        // 앱 값이 그누보드 변수(extract)로 풀리지 않게: 처리 파일에 넘길 값은 BoardMoa_Engine::input 으로 따로 넣는다
        $_POST = array();
        $_GET = array('r' => isset($_GET['r']) ? (string)$_GET['r'] : '');
        $_REQUEST = $_GET;
        BoardMoa_Session::install();
        register_shutdown_function(array(__CLASS__, 'onShutdown'));
        ob_start();
    }

    /** 처리 파일·common.php 가 JSON 대신 화면을 찍고 끝냈다(die·exit): 그 글자로 403 blocked */
    public static function onShutdown()
    {
        if (self::$responded) {
            return;
        }
        $output = '';
        while (ob_get_level() > 0) {
            $output = ob_get_clean() . $output;
        }
        $error = error_get_last();
        if ($error && in_array($error['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR), true)) {
            error_log('[boardmoa] ' . $error['message'] . ' @ ' . $error['file'] . ':' . $error['line']);
            self::sendJson(array('ok' => false, 'error' => array('code' => 'server_error', 'message' => BoardMoa_Text::t('서버에서 처리하지 못했습니다.'))), 500);
            return;
        }
        $text = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags(preg_replace('#<(script|style)\b.*?</\1>#is', '', $output)), ENT_QUOTES, 'UTF-8')));
        self::sendJson(array('ok' => false, 'error' => array('code' => 'blocked', 'message' => $text !== '' ? mb_substr($text, 0, 500) : BoardMoa_Text::t('처리하지 못했습니다.'))), 403);
    }

    // ---- 응답

    public static function sendJson($body, $status)
    {
        self::$responded = true;
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        if (!headers_sent()) {
            if (function_exists('header_remove')) {
                header_remove('Set-Cookie');
                header_remove('Location');
                header_remove('Refresh');
                header_remove('Expires');
                header_remove('Last-Modified');
                header_remove('Pragma');
            }
            http_response_code((int)$status);
            header('Content-Type: application/json; charset=utf-8');
            header('Cache-Control: no-store, private');
            header('Vary: Authorization, X-AppApi-Token, X-App-Lang, X-Content-Lang');
            header('X-Content-Type-Options: nosniff');
        }
        echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
    }

    /** common.php 다음에 api.php 가 부른다 */
    public static function handle()
    {
        $status = 200;
        try {
            BoardMoa_Store::ensureTables();
            BoardMoa_Engine::hook();
            $route = isset(self::$input['r']) ? (string)self::$input['r'] : '';
            $routes = self::routes();
            if (!isset($routes[$route])) {
                throw new BoardMoa_Error(404, 'unknown_route', 'unknown route', true);
            }
            list($method, $login, $handler) = $routes[$route];
            $methods = explode('|', $method);
            $requestMethod = strtoupper(isset($_SERVER['REQUEST_METHOD']) ? (string)$_SERVER['REQUEST_METHOD'] : 'GET');
            if (!in_array($requestMethod, $methods, true) && !(in_array('GET', $methods, true) && $requestMethod === 'HEAD')) {
                throw new BoardMoa_Error(405, 'method_not_allowed', 'method not allowed', true);
            }
            if ($login !== null) {
                self::authenticate($login);
            }
            $data = call_user_func($handler);
            if ($data === null) {
                self::$responded = true;
                exit; // 처리기가 직접 응답했다 (파일 내려받기)
            }
            $body = array('ok' => true, 'data' => $data);
        } catch (BoardMoa_Error $e) {
            $status = $e->status;
            $body = array('ok' => false, 'error' => array_merge(array('code' => $e->codeName, 'message' => $e->raw ? $e->getMessage() : BoardMoa_Text::t($e->getMessage())), $e->extra));
        } catch (BoardMoa_Alert $e) {
            // 처리 파일이 알맞은 오류로 바꾸지 않은 alert: 그누보드 문구 그대로
            $status = 403;
            $body = array('ok' => false, 'error' => array('code' => 'not_permitted', 'message' => $e->getMessage()));
        } catch (Throwable $e) {
            error_log('[boardmoa] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
            $status = 500;
            $body = array('ok' => false, 'error' => array('code' => 'server_error', 'message' => BoardMoa_Text::t('서버에서 처리하지 못했습니다.')));
        }
        self::sendJson($body, $status);
        exit;
    }

    /** 권한 없음: 비회원이면 401(앱이 로그인을 권한다), 회원이면 403 */
    public static function denied($message = null)
    {
        return new BoardMoa_Error(self::member() ? 403 : 401, 'not_permitted', $message !== null ? $message : '권한이 없습니다.');
    }

    // ---- 입력

    public static function param($name, $default = null)
    {
        $input = self::$input === null ? array() : self::$input;
        if (!array_key_exists($name, $input) || $input[$name] === null) {
            return $default;
        }
        $value = $input[$name];
        if (is_bool($value)) {
            return $value ? '1' : '';
        }
        return is_scalar($value) ? (string)$value : $value;
    }

    public static function intParam($name, $default = 0)
    {
        $value = self::param($name);
        return is_numeric($value) ? (int)$value : $default;
    }

    public static function boolParam($name)
    {
        $value = self::param($name, '');
        return in_array(strtolower((string)$value), array('1', 'true', 'y', 'yes', 'on'), true);
    }

    public static function ip()
    {
        return isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '';
    }

    // ---- 인증

    private static function bearer()
    {
        $header = isset($_SERVER['HTTP_AUTHORIZATION']) ? (string)$_SERVER['HTTP_AUTHORIZATION'] : '';
        if ($header === '' && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
            $header = (string)$_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
        }
        if ($header === '' && function_exists('apache_request_headers')) {
            foreach ((array)apache_request_headers() as $name => $value) {
                if (strtolower($name) === 'authorization') {
                    $header = (string)$value;
                }
            }
        }
        if (stripos($header, 'Bearer ') === 0) {
            return trim(substr($header, 7));
        }
        // 공유 호스팅·프록시가 Authorization 을 떨어뜨려도: 앱이 같은 토큰을 이 머리말로 한 번 더 보낸다
        return isset($_SERVER['HTTP_X_APPAPI_TOKEN']) ? trim((string)$_SERVER['HTTP_X_APPAPI_TOKEN']) : '';
    }

    /**
     * 세션을 열 때(BoardMoa_Session::read, DB 연결 뒤) 토큰을 확인해 그누보드 로그인 세션 값을 채운다.
     * 비밀번호를 바꾼 회원이면 토큰을 지운다. 차단·탈퇴는 common.php 가 웹처럼 확인한다.
     */
    public static function resolveToken()
    {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;
        // 앱은 휴대폰 화면: 모바일 판을 쓰는 사이트면 웹의 모바일 화면처럼 (메뉴·쪽 수·PC 전용 게시판, common.php 의 ss_is_mobile)
        BoardMoa_Session::$seed = array('ss_is_mobile' => true);
        $access = self::bearer();
        if ($access === '' || self::routeIgnoresToken()) {
            return;
        }
        BoardMoa_Store::ensureTables();
        $row = BoardMoa_Store::findByAccess($access);
        if (!$row) {
            self::$authError = array('token_expired', 'access token expired');
            return;
        }
        $mb = get_member($row['mb_id']);
        if (empty($mb['mb_id'])) {
            BoardMoa_Store::revokeMember($row['mb_id']);
            self::$authError = array('session_revoked', '로그인할 수 없는 계정입니다.');
            return;
        }
        if (!hash_equals((string)$row['password_sig'], BoardMoa_Store::passwordSig($mb['mb_password']))) {
            BoardMoa_Store::revoke((int)$row['token_id']);
            self::$authError = array('session_revoked', 'password changed');
            return;
        }
        self::$token = $row;
        self::$tokenMember = (string)$mb['mb_id'];
        BoardMoa_Session::$seed += array(
            'ss_mb_id' => (string)$mb['mb_id'],
            'ss_mb_token_key' => function_exists('get_token_encryption_key') ? get_token_encryption_key($mb['mb_datetime']) : '',
        );
    }

    /** 로그인·토큰 갱신·로그아웃은 Bearer 를 보지 않는다 (만료된 토큰이 붙어 와도) */
    private static function routeIgnoresToken()
    {
        $r = isset(self::$input['r']) ? (string)self::$input['r'] : '';
        return in_array($r, array('auth.login', 'auth.refresh', 'auth.logout'), true);
    }

    /** 이번 요청의 회원 (그누보드 $member), 비회원이면 null */
    public static function member()
    {
        global $member;
        return (is_array($member) && !empty($member['mb_id'])) ? $member : null;
    }

    private static function authenticate($required)
    {
        if (self::$authError) {
            throw new BoardMoa_Error(401, self::$authError[0], self::$authError[1]);
        }
        $member = self::member();
        if (self::$token && !$member) {
            // 토큰은 맞지만 common.php 가 로그인을 풀었다 (차단·탈퇴한 회원)
            BoardMoa_Store::revokeMember(self::$tokenMember);
            throw new BoardMoa_Error(401, 'session_revoked', '로그인할 수 없는 계정입니다.');
        }
        if (!$member) {
            if ($required) {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            return;
        }
        if (self::$token) {
            BoardMoa_Store::touch(self::$token);
        }
    }

    /** 웹 로그인 처리 파일(bbs/login_check.php)을 그대로 실행한다: 비밀번호 확인·차단·탈퇴·소셜 로그인·로그인 훅·포인트가 웹과 같다 */
    public static function login()
    {
        global $config, $g5;
        $id = trim((string)self::param('user_id', ''));
        $password = (string)self::param('password', '');
        if ($id === '' || $password === '') {
            throw new BoardMoa_Error(400, 'missing_credentials', '아이디와 비밀번호를 입력하세요.');
        }
        // 로그인 시도 제한 (1.0.18~): 같은 IP 에서 같은 아이디로 10분에 10번, 아이디 상관없이 30번 틀리면 잠시 막는다 (그누보드 코어에는 제한이 없다)
        $who = 'login|' . strtolower(preg_replace('/[^A-Za-z0-9_]/', '', $id));
        BoardMoa_Write::limit($who, 10, '로그인을 여러 번 실패했습니다. 잠시 뒤에 다시 해 주세요.');
        BoardMoa_Write::limit('login', 30, '로그인을 여러 번 실패했습니다. 잠시 뒤에 다시 해 주세요.');
        $mb = get_member(preg_replace('/[^A-Za-z0-9_]/', '', $id));
        // 메일 인증을 쓰는 사이트에서 인증하지 않은 회원: 웹은 확인 창(confirm)을 띄우는데 앱에는 그 창이 없다
        if (!empty($mb['mb_id']) && function_exists('is_use_email_certify') && is_use_email_certify() && !preg_match('/[1-9]/', (string)$mb['mb_email_certify'])
            && login_password_check($mb, $password, $mb['mb_password'])) {
            throw new BoardMoa_Error(403, 'not_permitted', BoardMoa_Text::t('{0} 메일로 메일 인증을 받아야 로그인할 수 있습니다.', $mb['mb_email']), true);
        }
        BoardMoa_Engine::input(array('mb_id' => $id, 'mb_password' => $password));
        try {
            $run = BoardMoa_Engine::run(G5_BBS_PATH . '/login_check.php');
        } catch (BoardMoa_Alert $e) {
            $text = $e->getMessage();
            if (strpos($text, '비밀번호가 틀립니다') !== false || strpos($text, '회원아이디나 비밀번호가 공백') !== false) {
                BoardMoa_Write::hit($who);
                BoardMoa_Write::hit('login');
                throw new BoardMoa_Error(401, 'login_failed', self::socialUser($mb) ? '아이디 또는 비밀번호가 맞지 않습니다. 소셜 로그인으로 가입한 계정이면 웹사이트에서 비밀번호를 정한 뒤 앱에서 로그인해 주세요.' : '아이디 또는 비밀번호가 맞지 않습니다.');
            }
            // 차단·탈퇴·로그인 훅(로그인 제한 플러그인 등)이 막은 까닭은 그대로
            throw new BoardMoa_Error(403, 'not_permitted', $text, true);
        }
        $loggedIn = isset($_SESSION['ss_mb_id']) ? (string)$_SESSION['ss_mb_id'] : '';
        if ($loggedIn === '' || $run['redirect'] === null) {
            throw new BoardMoa_Error(403, 'not_permitted', '로그인할 수 없습니다.');
        }
        $mb = get_member($loggedIn);
        $tokens = BoardMoa_Store::issue($mb['mb_id'], $mb['mb_password'], self::param('device_name', ''), self::param('platform', ''), self::ip());
        return array('tokens' => $tokens, 'member' => self::profile($mb));
    }

    /**
     * 소셜 로그인(plugin/social)으로 가입한 계정일 수 있는지: 비밀번호가 틀렸을 때 알맞은 안내를 하려고.
     * 소셜로 가입한 회원은 임의 비밀번호에 아이디도 '공급자_번호' 꼴이라, 사이트가 소셜 로그인을 쓰면 없는 아이디에도 안내한다.
     */
    private static function socialUser($mb)
    {
        global $config, $g5;
        if (empty($config['cf_social_login_use'])) {
            return false;
        }
        if (empty($mb['mb_id'])) {
            return true;
        }
        if (empty($g5['social_profile_table'])) {
            return false;
        }
        $row = sql_fetch(" select mp_no from {$g5['social_profile_table']} where mb_id = '" . sql_real_escape_string($mb['mb_id']) . "' limit 1 ", false);
        return !empty($row['mp_no']);
    }

    public static function refresh()
    {
        $result = BoardMoa_Store::rotate((string)self::param('refresh_token', ''), self::ip());
        if (!$result) {
            throw new BoardMoa_Error(401, 'refresh_invalid', 'login required', true);
        }
        $row = $result[0];
        $mb = get_member($row['mb_id']);
        $today = date('Ymd', G5_SERVER_TIME);
        if (empty($mb['mb_id']) || !hash_equals((string)$row['password_sig'], BoardMoa_Store::passwordSig($mb['mb_password']))
            || ($mb['mb_intercept_date'] && $mb['mb_intercept_date'] <= $today) || ($mb['mb_leave_date'] && $mb['mb_leave_date'] <= $today)) {
            BoardMoa_Store::revoke((int)$row['token_id']);
            throw new BoardMoa_Error(401, 'session_revoked', '로그인할 수 없는 계정입니다.');
        }
        return array('tokens' => $result[1]);
    }

    public static function logout()
    {
        $row = BoardMoa_Store::findByAccess(self::bearer());
        if (!$row && self::param('refresh_token')) {
            $result = BoardMoa_Store::rotate((string)self::param('refresh_token'), self::ip());
            $row = $result ? $result[0] : null;
        }
        if ($row) {
            BoardMoa_Store::revoke((int)$row['token_id']);
        }
        return array('logged_out' => true);
    }

    /** GET auth.devices: 최근에 쓴 것부터. current 는 이 요청의 토큰 */
    public static function devices()
    {
        $member = self::member();
        $current = self::$token ? (int)self::$token['token_id'] : 0;
        $devices = array();
        foreach (BoardMoa_Store::devices($member['mb_id']) as $row) {
            $devices[] = array(
                'device_srl' => (int)$row['token_id'],
                'device_name' => (string)$row['device_name'],
                'platform' => (string)$row['platform'],
                'created' => $row['created'] ? date('c', (int)$row['created']) : null,
                'last_used' => $row['last_used'] ? date('c', (int)$row['last_used']) : null,
                'current' => (int)$row['token_id'] === $current,
            );
        }
        return array('devices' => $devices);
    }

    /** POST auth.devices.revoke {device_srl}: 자기 토큰 줄만. 지금 기기면 로그아웃과 같다 */
    public static function revokeDevice()
    {
        $member = self::member();
        $srl = self::intParam('device_srl');
        if ($srl <= 0 || !BoardMoa_Store::revokeOwn($member['mb_id'], $srl)) {
            throw new BoardMoa_Error(404, 'not_found', '없는 페이지입니다.');
        }
        return array('revoked' => true);
    }

    public static function me()
    {
        global $config;
        $out = self::profile(self::member());
        if (!empty($config['cf_use_point'])) {
            $mb = self::member();
            $out['point'] = (int)$mb['mb_point'];
            $out['level'] = (int)$mb['mb_level'];
            $out['point_name'] = BoardMoa_Text::t('포인트');
        }
        return $out;
    }

    /** 앱의 member 객체 (비회원이면 null) */
    public static function profile($mb)
    {
        if (!$mb || empty($mb['mb_id'])) {
            return null;
        }
        return array(
            'member_srl' => (int)$mb['mb_no'],
            'user_id' => (string)$mb['mb_id'],
            'nick_name' => (string)$mb['mb_nick'],
            // 이름 (1.0.20~): 본인에게만 보내는 회원 정보라 그대로. 없으면 null
            'user_name' => trim((string)$mb['mb_name']) !== '' ? trim((string)$mb['mb_name']) : null,
            'email_address' => $mb['mb_email'] !== '' ? (string)$mb['mb_email'] : null,
            'profile_image' => self::avatar($mb['mb_id']),
            'groups' => array(BoardMoa_Text::t('{0}등급', (int)$mb['mb_level'])),
            'is_admin' => is_admin($mb['mb_id']) === 'super',
        );
    }

    /** 회원 사진 (그누보드 '회원 이미지': data/member_image/앞두글자/아이디.gif, get_member_profile_img 와 같은 곳). 없으면 null */
    public static function avatar($mbId)
    {
        static $cache = array();
        $mbId = (string)$mbId;
        if ($mbId === '') {
            return null;
        }
        if (!array_key_exists($mbId, $cache)) {
            $rel = 'member_image/' . substr($mbId, 0, 2) . '/' . get_mb_icon_name($mbId) . '.gif';
            $cache[$mbId] = is_file(G5_DATA_PATH . '/' . $rel) ? G5_DATA_URL . '/' . $rel . '?' . filemtime(G5_DATA_PATH . '/' . $rel) : null;
        }
        return $cache[$mbId];
    }

    public static function noNotify()
    {
        return array('enabled' => false, 'unread' => 0);
    }
}
