<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/**
 * 회원가입 (1.0.28~). 웹 가입(bbs/register.php 약관 → register_form.php 양식 → register_form_update.php, w='')과 같은 설정·같은 처리 파일.
 * - 양식: 기본 회원 스킨의 가입 화면과 같은 칸(아이디·비밀번호·이름·닉네임·이메일 + 사이트 설정 '…사용' 칸), 약관 두 개(회원가입약관·개인정보 수집 및 이용)
 * - 저장: 처리 파일을 그대로 실행해 아이디·닉네임·메일 검사, 금지어, 자동등록방지(캡챠), 메일 인증, 가입 포인트·레벨, 알림 메일, 훅이 웹과 같다
 * - 본인확인을 꼭 해야 하는 사이트(cf_cert_req)와 앱이 풀 수 없는 캡챠(보이지 않는 reCAPTCHA)는 웹으로 안내(web_only)
 */
class BoardMoa_Signup
{
    /** 웹 가입 양식의 '…사용' 칸: 이름 => [제목, 형식, 필수] */
    private static function optionalFields()
    {
        global $config;
        $out = array();
        if (!empty($config['cf_use_homepage'])) {
            $out['mb_homepage'] = array('홈페이지', 'url', !empty($config['cf_req_homepage']));
        }
        if (!empty($config['cf_use_tel'])) {
            $out['mb_tel'] = array('전화번호', 'tel', !empty($config['cf_req_tel']));
        }
        if (!empty($config['cf_use_hp']) || !empty($config['cf_req_hp'])) {
            $out['mb_hp'] = array('휴대폰번호', 'tel', !empty($config['cf_req_hp']));
        }
        if (!empty($config['cf_use_addr'])) {
            $out['mb_addr'] = array('주소', 'kr_zip', !empty($config['cf_req_addr']));
        }
        if (!empty($config['cf_use_signature'])) {
            $out['mb_signature'] = array('서명', 'textarea', !empty($config['cf_req_signature']));
        }
        if (!empty($config['cf_use_profile'])) {
            $out['mb_profile'] = array('자기소개', 'textarea', !empty($config['cf_req_profile']));
        }
        if (!empty($config['cf_use_recommend'])) {
            $out['mb_recommend'] = array('추천인아이디', 'text', false);
        }
        return $out;
    }

    private static function field($name, $title, $type, $required, array $options = array(), array $parts = array())
    {
        return array('name' => $name, 'title' => BoardMoa_Text::t($title), 'type' => $type, 'required' => (bool)$required, 'value' => '',
            'options' => $options, 'parts' => $parts, 'editable' => true);
    }

    /** 앱에서 가입할 수 없어 웹으로 보내야 하는가 (본인확인 필수) */
    private static function needsWeb()
    {
        global $config;
        return !empty($config['cf_cert_use']) && !empty($config['cf_cert_req']);
    }

    /** GET signup.form */
    public static function form()
    {
        global $config;
        $web = G5_BBS_URL . '/register.php';
        $widget = BoardMoa_Write::captchaWidget();
        $fields = array(self::field('mb_name', '이름', 'text', true));
        foreach (self::optionalFields() as $name => $info) {
            $fields[] = self::field($name, $info[0], $info[1], $info[2], array(), $info[1] === 'kr_zip' ? array('우편번호', '주소', '상세 주소', '참고 항목') : array());
        }
        $fields[] = self::field('mb_open', '정보공개', 'checkbox', false, array(BoardMoa_Text::t('다른 분들이 내 정보를 볼 수 있게 합니다')));
        return array(
            'enabled' => true,
            // 가입에 늘 자동등록방지를 쓴다: 위젯을 아는 앱(captcha_solve)은 web_only 라도 앱에서 풀고 가입한다. 예전 앱은 웹으로
            'web_only' => true,
            'captcha' => !self::needsWeb(),
            'captcha_widget' => self::needsWeb() ? null : $widget,
            'web_url' => $web,
            'basic' => array(
                array('name' => 'user_id', 'title' => BoardMoa_Text::t('아이디'), 'required' => true),
                array('name' => 'nick_name', 'title' => BoardMoa_Text::t('닉네임'), 'required' => true),
                array('name' => 'email_address', 'title' => BoardMoa_Text::t('이메일'), 'required' => true),
            ),
            'agreements' => array(
                array('index' => 0, 'title' => BoardMoa_Text::t('회원가입약관'), 'content' => self::plain($config['cf_stipulation']), 'required' => true),
                array('index' => 1, 'title' => BoardMoa_Text::t('개인정보 수집 및 이용'), 'content' => self::plain($config['cf_privacy']), 'required' => true),
            ),
            'password_hint' => BoardMoa_Text::t('비밀번호를 3~20글자로 입력해 주세요.'),
            'needs_confirm' => !empty($config['cf_use_email_certify']),
            'fields' => $fields,
        );
    }

    private static function plain($html)
    {
        $text = preg_replace('#<(br|/p|/h[1-6]|/li|/div|/tr)\b[^>]*>#i', "\n", (string)$html);
        $text = html_entity_decode(strip_tags($text), ENT_QUOTES, 'UTF-8');
        return trim(preg_replace("/\n{3,}/", "\n\n", preg_replace("/[ \t]+\n/", "\n", $text)));
    }

    /** POST signup {user_id, nick_name, email_address, password, agreements, fields, captcha_response, device_name, platform} */
    public static function signup()
    {
        global $config;
        if (self::needsWeb()) {
            throw new BoardMoa_Error(403, 'not_permitted', '본인확인이 필요한 사이트입니다. 웹사이트에서 가입해 주세요.');
        }
        include_once G5_LIB_PATH . '/register.lib.php';
        $accepted = array_map('intval', (array)BoardMoa_Api::param('agreements', array()));
        if (!in_array(0, $accepted, true) || !in_array(1, $accepted, true)) {
            throw new BoardMoa_Error(400, 'signup_failed', '필수 약관에 동의해 주세요.');
        }
        $id = trim((string)BoardMoa_Api::param('user_id', ''));
        $nick = trim((string)BoardMoa_Api::param('nick_name', ''));
        $email = trim((string)BoardMoa_Api::param('email_address', ''));
        $password = trim((string)BoardMoa_Api::param('password', ''));
        // 웹 양식이 보내기 전에 확인하는 것(ajax.mb_id.php·ajax.mb_nick.php, 입력 칸 길이) 중 처리 파일이 다시 보지 않는 것
        if (mb_strlen($password) < 3 || mb_strlen($password) > 20) {
            throw new BoardMoa_Error(400, 'signup_failed', '비밀번호를 3~20글자로 입력해 주세요.');
        }
        if ($msg = count_mb_nick($nick)) {
            throw new BoardMoa_Error(400, 'signup_failed', $msg, true);
        }
        $values = array('w' => '', 'mb_id' => $id, 'mb_password' => $password, 'mb_password_re' => $password,
            'mb_nick' => $nick, 'mb_email' => $email, 'mb_name' => '', 'agree' => '1', 'agree2' => '1');
        $sent = BoardMoa_Api::param('fields');
        if (is_string($sent) && $sent !== '') {
            $sent = json_decode($sent, true);
        }
        $sent = is_array($sent) ? $sent : array();
        $optional = self::optionalFields();
        $values['mb_name'] = isset($sent['mb_name']) && !is_array($sent['mb_name']) ? trim((string)$sent['mb_name']) : '';
        foreach ($optional as $name => $info) {
            $value = isset($sent[$name]) && !is_array($sent[$name]) ? trim((string)$sent[$name]) : '';
            if ($name === 'mb_addr') {
                $parts = array_map('trim', array_pad(explode("\n", str_replace("\r", '', $value)), 4, ''));
                $values['mb_zip'] = preg_replace('/[^0-9]/', '', $parts[0]);
                $values['mb_addr1'] = $parts[1];
                $values['mb_addr2'] = $parts[2];
                $values['mb_addr3'] = $parts[3];
                $values['mb_addr_jibeon'] = $parts[1] !== '' ? 'R' : '';
                $empty = $values['mb_zip'] === '' || $parts[1] === '';
            } else {
                $values[$name] = $value;
                $empty = $value === '';
            }
            // 웹 양식의 필수 칸(required): 처리 파일은 다시 보지 않는다
            if ($info[2] && $empty) {
                throw new BoardMoa_Error(400, 'signup_failed', BoardMoa_Text::t('{0} 항목을 입력해 주세요.', BoardMoa_Text::t($info[0])), true);
            }
        }
        $values['mb_open'] = !empty($sent['mb_open']) ? '1' : '0';

        // 자동등록방지: 웹 가입 양식처럼 늘 (처리 파일의 chk_captcha 가 확인한다)
        $widget = BoardMoa_Write::captchaWidget();
        if (!$widget) {
            throw new BoardMoa_Error(403, 'captcha_required', '자동등록방지 확인이 필요합니다.', false, array('captcha' => null));
        }
        if (!BoardMoa_Write::captchaPass((string)BoardMoa_Api::param('captcha_response', ''), $widget)) {
            throw new BoardMoa_Error(403, 'captcha_required', '자동등록방지 확인이 필요합니다.', false, array('captcha' => $widget));
        }
        // register_form.php 가 양식을 열 때·ajax 확인이 넣는 세션 값 (아이디·닉네임·메일 확인은 처리 파일이 다시 한다)
        set_session('ss_check_mb_id', $id);
        set_session('ss_check_mb_nick', $nick);
        set_session('ss_check_mb_email', $email);
        set_session('ss_cert_no', '');
        set_session('ss_cert_hash', '');
        set_session('ss_cert_type', '');
        BoardMoa_Engine::input($values);
        try {
            BoardMoa_Engine::run(G5_BBS_PATH . '/register_form_update.php');
        } catch (BoardMoa_Alert $e) {
            if (strpos($e->getMessage(), '자동등록방지') !== false) {
                throw new BoardMoa_Error(403, 'captcha_required', $e->getMessage(), true, array('captcha' => BoardMoa_Write::captchaWidget()));
            }
            throw new BoardMoa_Error(400, 'signup_failed', $e->getMessage(), true);
        }
        $mb = get_member($id);
        if (empty($mb['mb_id'])) {
            throw new BoardMoa_Error(400, 'signup_failed', '가입하지 못했습니다.');
        }
        if (!empty($config['cf_use_email_certify'])) {
            return array('needs_confirm' => true);
        }
        $tokens = BoardMoa_Store::issue($mb['mb_id'], $mb['mb_password'], BoardMoa_Api::param('device_name', ''), BoardMoa_Api::param('platform', ''), BoardMoa_Api::ip());
        return array('needs_confirm' => false, 'logged_in' => true, 'tokens' => $tokens, 'member' => BoardMoa_Api::profile($mb));
    }
}
