<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/** 그누보드 처리 파일이 alert() 로 끝내려 했다 (거절 이유) */
class BoardMoa_Alert extends Exception
{
    public $url;

    public function __construct($message, $url)
    {
        parent::__construct((string)$message);
        $this->url = (string)$url;
    }
}

/** 그누보드 처리 파일이 goto_url() 로 다음 화면에 보내려 했다 (보통 성공) */
class BoardMoa_Redirect extends Exception
{
    public $url;

    public function __construct($url)
    {
        parent::__construct('redirect');
        $this->url = (string)$url;
    }
}

/**
 * 웹의 처리 파일(bbs/write_update.php·login_check.php 등)을 그대로 실행한다. 그래서 권한·포인트·금지어·도배 방지·알림 메일·훅이 웹과 같다.
 * 그누보드의 alert()·goto_url() 은 끝내기 전에 훅(run_event 'alert'·'goto_url')을 부르므로, 그 훅에서 예외를 던져 처리 파일을 멈추고 결과를 받는다.
 * 처리 파일은 전역 변수($g5, $member, $board …)를 쓰므로 전역 변수를 참조로 끌어온 자리에서 include 한다.
 */
class BoardMoa_Engine
{
    private static $running = 0;
    private static $hooked = false;

    public static function hook()
    {
        if (self::$hooked || !function_exists('add_event')) {
            return;
        }
        self::$hooked = true;
        // 그누보드 훅은 [클래스, 메서드] 를 싱글턴(getInstance)으로 부르므로 익명 함수로 넘긴다
        add_event('alert', function ($msg = '', $url = '', $error = true, $post = false) {
            BoardMoa_Engine::onAlert($msg, $url, $error, $post);
        }, 1, 4);
        add_event('goto_url', function ($url = '') {
            BoardMoa_Engine::onGoto($url);
        }, 1, 1);
        // 저장된 글·댓글 번호 (처리 파일이 끝에 부르는 훅)
        add_event('write_update_after', function ($board = null, $wr_id = 0) {
            BoardMoa_Engine::$captured['wr_id'] = (int)$wr_id;
        }, 1, 2);
        add_event('comment_update_after', function ($board = null, $wr_id = 0, $w = '', $qstr = '', $redirect = '', $comment_id = 0) {
            BoardMoa_Engine::$captured['comment_id'] = (int)$comment_id;
        }, 1, 6);
        add_event('memo_form_update_after', function ($member_list = array()) {
            BoardMoa_Engine::$captured['memo_sent'] = isset($member_list['id']) ? count($member_list['id']) : 1;
        }, 1, 1);
    }

    /** 처리 파일이 저장한 번호 (write_update_after·comment_update_after) */
    public static $captured = array();

    public static function onAlert($msg = '', $url = '', $error = true, $post = false)
    {
        if (self::$running > 0) {
            throw new BoardMoa_Alert(self::alertText($msg), $url);
        }
    }

    public static function onGoto($url = '')
    {
        if (self::$running > 0) {
            throw new BoardMoa_Redirect($url);
        }
    }

    /** alert() 문구: 태그를 빼고 \n(글자 그대로 쓴 것)을 줄바꿈으로 */
    public static function alertText($msg)
    {
        $msg = (string)$msg;
        if ($msg === '') {
            return '올바른 방법으로 이용해 주십시오.';
        }
        $msg = str_replace(array('\\n', '<br>', '<br/>', '<br />'), "\n", $msg);
        $msg = html_entity_decode(strip_tags($msg), ENT_QUOTES, 'UTF-8');
        return trim(preg_replace("/\n{3,}/", "\n\n", $msg));
    }

    /** common.php 가 $_POST 에 하는 이스케이프 (비밀번호도 이 값으로 암호화돼 저장된다) */
    public static function escape($value)
    {
        return call_user_func(defined('G5_ESCAPE_FUNCTION') ? G5_ESCAPE_FUNCTION : 'addslashes', (string)$value);
    }

    /**
     * 처리 파일이 받는 꼴로 넣는다: common.php 처럼 G5_ESCAPE_FUNCTION 을 거친 값을 $_POST(또는 $_GET)와,
     * common.php 의 extract($_GET)·extract($_POST) 처럼 같은 이름의 전역 변수에. $_REQUEST 는 웹처럼 거치지 않은 값.
     */
    public static function input(array $values, $get = false)
    {
        $escape = defined('G5_ESCAPE_FUNCTION') ? G5_ESCAPE_FUNCTION : 'addslashes';
        foreach ($values as $key => $value) {
            $escaped = is_array($value) ? array_map($escape, array_map('strval', $value)) : call_user_func($escape, (string)$value);
            if ($get) {
                $_GET[$key] = $escaped;
            } else {
                $_POST[$key] = $escaped;
            }
            $_REQUEST[$key] = is_array($value) ? $value : (string)$value;
            $GLOBALS[$key] = $escaped;
        }
    }

    /**
     * 처리 파일 실행. 성공해서 다음 화면으로 보내려 하면 ['redirect' => 주소, 'output' => 찍은 글자],
     * alert 로 거절하면 BoardMoa_Alert 를 던진다. 끝까지 아무 이동 없이 끝나면 ['redirect' => null, 'output' => …].
     */
    public static function run($file)
    {
        self::hook();
        $level = ob_get_level();
        ob_start();
        self::$running++;
        $cwd = getcwd();
        chdir(dirname($file)); // 처리 파일의 include_once('./_common.php') 가 제자리를 찾게
        try {
            self::includeGlobal($file);
            $result = array('redirect' => null, 'output' => '');
        } catch (BoardMoa_Redirect $r) {
            $result = array('redirect' => $r->url, 'output' => '');
        } finally {
            self::$running--;
            if ($cwd !== false) {
                chdir($cwd);
            }
            $output = '';
            while (ob_get_level() > $level) {
                $output = ob_get_clean() . $output;
            }
        }
        $result['output'] = $output;
        return $result;
    }

    /** 전역 변수를 참조로 이 자리에 끌어와 include (처리 파일이 새로 만든 변수는 이 함수 안에 남는다) */
    private static function includeGlobal($__file)
    {
        foreach (array_keys($GLOBALS) as $__name) {
            if ($__name !== 'GLOBALS' && $__name !== '__file' && $__name !== '__name' && preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $__name)) {
                $$__name = &$GLOBALS[$__name];
            }
        }
        unset($__name);
        include $__file;
    }
}
