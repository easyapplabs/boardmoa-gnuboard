<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/**
 * 사이트·메뉴·모아 보기·게시판 목록·본문·댓글·첨부·링크 풀이.
 *
 * mid: 게시판은 bo_table 그대로, 내용 페이지(bbs/content.php)는 content-<co_id>.
 * 권한은 그누보드 화면 파일과 같은 순서로 본다 (bbs/board.php·view.php·view_comment.php·download.php):
 *   목록 = 회원 레벨 ≥ 목록 레벨 (+ 본인확인 게시판), 글 읽기 = 그룹 접근(그룹 회원·관리자) → 읽기 레벨 → 본인확인 → 비밀글.
 *   그누보드는 그룹 접근 게시판도 목록(제목)은 레벨만 보고, 글을 열 때 그룹 회원을 확인한다 — 앱도 같다.
 * 목록을 볼 수 없는 게시판은 메뉴·모아 보기·링크 어디에도 내보내지 않는다.
 */
class BoardMoa_Boards
{
    const MAX_FEED_PAGE = 50;
    const CONTENT_PREFIX = 'content-';
    /** 첫 화면 페이지 mid (게시판 이름은 영문 소문자·숫자·_ 라 '-' 가 든 이 이름과 겹치지 않는다) */
    const HOME = 'home-latest';

    private static $boards = null;
    private static $groupMember = array();
    private static $mbNo = array();

    // ---- 게시판 정보

    /** 모든 게시판 (bo_table => 행, 그룹 정보 포함, 그룹·게시판 순서) */
    public static function all()
    {
        global $g5;
        if (self::$boards === null) {
            self::$boards = array();
            $result = sql_query(" select b.*, g.gr_subject, g.gr_use_access, g.gr_admin, g.gr_order from {$g5['board_table']} b
                left join {$g5['group_table']} g on b.gr_id = g.gr_id order by g.gr_order, b.gr_id, b.bo_order, b.bo_table ");
            while ($row = sql_fetch_array($result)) {
                self::$boards[$row['bo_table']] = $row;
            }
        }
        return self::$boards;
    }

    public static function get($boTable)
    {
        $all = self::all();
        return isset($all[$boTable]) ? $all[$boTable] : null;
    }

    public static function title($b)
    {
        return BoardMoa_Html::text(($b['bo_mobile_subject'] !== '' && G5_IS_MOBILE) ? $b['bo_mobile_subject'] : $b['bo_subject']);
    }

    private static function member()
    {
        return BoardMoa_Api::member();
    }

    private static function level()
    {
        $m = self::member();
        return $m ? (int)$m['mb_level'] : 1;
    }

    private static function mbId()
    {
        $m = self::member();
        return $m ? (string)$m['mb_id'] : '';
    }

    /** 이 게시판에서의 관리자 종류 (그누보드 is_admin: super·group·board·'') — 웹처럼 $board·$group 을 그 게시판으로 놓고 부른다 */
    public static function adminOf($b)
    {
        $id = self::mbId();
        if ($id === '') {
            return '';
        }
        $savedBoard = isset($GLOBALS['board']) ? $GLOBALS['board'] : null;
        $savedGroup = isset($GLOBALS['group']) ? $GLOBALS['group'] : null;
        $GLOBALS['board'] = $b;
        $GLOBALS['group'] = array('gr_id' => $b['gr_id'], 'gr_admin' => (string)$b['gr_admin'], 'gr_use_access' => $b['gr_use_access']);
        $admin = is_admin($id);
        $GLOBALS['board'] = $savedBoard;
        $GLOBALS['group'] = $savedGroup;
        return (string)$admin;
    }

    /**
     * 처리 파일·그누보드 함수가 쓰는 전역 변수를 이 게시판(과 글)으로 맞춘다 (common.php 가 bo_table·wr_id 로 하는 것과 같다).
     */
    public static function context($b, $wrId = 0)
    {
        global $g5;
        $GLOBALS['bo_table'] = $b['bo_table'];
        $GLOBALS['board'] = get_board_db($b['bo_table'], true);
        $GLOBALS['write_table'] = $g5['write_prefix'] . $b['bo_table'];
        $GLOBALS['gr_id'] = $b['gr_id'];
        $GLOBALS['group'] = get_group($b['gr_id'], true);
        $GLOBALS['wr_id'] = (int)$wrId;
        $GLOBALS['write'] = $wrId ? get_write($GLOBALS['write_table'], (int)$wrId) : array();
        $id = self::mbId();
        $GLOBALS['is_admin'] = $id !== '' ? is_admin($id) : '';
        $skin = (G5_IS_MOBILE && $GLOBALS['board']['bo_mobile_skin']) ? $GLOBALS['board']['bo_mobile_skin'] : $GLOBALS['board']['bo_skin'];
        $GLOBALS['board_skin_path'] = get_skin_path('board', $skin);
        $GLOBALS['board_skin_url'] = get_skin_url('board', $skin);
        return $GLOBALS['board'];
    }

    /** 모바일 웹에서 열리는 게시판인가 (check_device: 모바일 판을 쓰는 사이트의 PC 전용 게시판은 휴대폰에서 막힌다) */
    private static function deviceOk($b)
    {
        return !(G5_IS_MOBILE && $b['bo_device'] === 'pc' && self::adminOf($b) === '');
    }

    /** 본인확인 게시판 (board.php: 본인확인을 쓰는 사이트에서 관리자 말고는 인증한 회원만) */
    private static function certOk($b)
    {
        global $config;
        if ($b['bo_use_cert'] === '' || empty($config['cf_cert_use']) || self::adminOf($b) !== '') {
            return true;
        }
        $m = self::member();
        if (!$m) {
            return false;
        }
        if ($b['bo_use_cert'] === 'cert' && !$m['mb_certify']) {
            return false;
        }
        if ($b['bo_use_cert'] === 'adult' && !$m['mb_adult']) {
            return false;
        }
        return true;
    }

    /** 목록을 볼 수 있는가 (board.php 목록 확인) */
    public static function canList($b)
    {
        return $b && self::level() >= (int)$b['bo_list_level'] && self::deviceOk($b) && self::certOk($b);
    }

    /** 그룹 접근 게시판이면 그룹 회원·관리자인가 (board.php 글 읽기, write.php) */
    public static function groupOk($b)
    {
        global $g5;
        if (empty($b['gr_use_access'])) {
            return true;
        }
        $id = self::mbId();
        if ($id === '') {
            return false;
        }
        $admin = self::adminOf($b);
        if ($admin === 'super' || $admin === 'group') {
            return true;
        }
        $key = $b['gr_id'];
        if (!isset(self::$groupMember[$key])) {
            $row = sql_fetch(" select count(*) as cnt from {$g5['group_member_table']} where gr_id = '" . sql_real_escape_string($b['gr_id']) . "' and mb_id = '" . sql_real_escape_string($id) . "' ");
            self::$groupMember[$key] = !empty($row['cnt']);
        }
        return self::$groupMember[$key];
    }

    /** 글을 읽을 수 있는가 (비밀글 말고): 그룹 접근 → 읽기 레벨 → 본인확인 */
    public static function canRead($b)
    {
        return self::canList($b) && self::groupOk($b) && self::level() >= (int)$b['bo_read_level'];
    }

    /** 읽기가 막힌 까닭 (board.php 의 alert 문구) — 앱에 그대로 보인다 */
    private static function readDenied($b)
    {
        $guest = !self::member();
        if (!self::groupOk($b)) {
            return BoardMoa_Api::denied($guest ? '비회원은 이 게시판에 접근할 권한이 없습니다.' : '접근 권한이 없으므로 글읽기가 불가합니다.');
        }
        return BoardMoa_Api::denied('글을 읽을 권한이 없습니다.');
    }

    public static function grant($b)
    {
        $read = self::canRead($b);
        $level = self::level();
        $admin = self::adminOf($b);
        return array(
            'list' => self::canList($b),
            'view' => $read,
            'write_document' => $read && $level >= (int)$b['bo_write_level'],
            'write_comment' => $read && $level >= (int)$b['bo_comment_level'],
            'manager' => in_array($admin, array('super', 'group', 'board'), true),
        );
    }

    /** mid 의 게시판. 없거나 목록을 볼 수 없으면 없는 게시판처럼 404 (비회원은 로그인을 권한다) */
    public static function find($mid)
    {
        $mid = (string)$mid;
        if (!preg_match('/^[A-Za-z0-9_\-]{1,80}$/', $mid)) {
            throw new BoardMoa_Error(400, 'invalid_mid', 'invalid mid', true);
        }
        if (strpos($mid, self::CONTENT_PREFIX) === 0) {
            throw new BoardMoa_Error(400, 'not_board', 'not a board', true);
        }
        $b = self::get($mid);
        if (!$b) {
            throw new BoardMoa_Error(404, 'board_not_found', '없는 게시판입니다.');
        }
        if (!self::canList($b)) {
            if (!self::member() && (int)$b['bo_list_level'] > 1) {
                throw new BoardMoa_Error(401, 'login_required', '로그인이 필요합니다.');
            }
            throw new BoardMoa_Error(404, 'board_not_found', '없는 게시판입니다.');
        }
        return $b;
    }

    // ---- 사이트

    public static function site()
    {
        global $config;
        // devices: 로그인한 기기 보기·로그아웃 (1.0.19~), page_view: 앱의 '페이지로 보기' (1.1.0~)
        $features = array_merge(array('resolve_path', 'devices', 'page_view'), BoardMoa_Write::features());
        return array(
            'name' => BoardMoa_Html::text($config['cf_title']) ?: (string)parse_url(G5_URL, PHP_URL_HOST),
            'names' => null,
            'share_site' => BoardMoa_Updater::shareSite(),
            'base_url' => BoardMoa_Html::base() . '/',
            'theme_color' => null,
            'logo_url' => self::logo(),
            'icon_url' => self::icon(),
            // 첫 화면: 그누보드 index.php 처럼 게시판별 최신 글 (page 'home'). 비워 두면 iOS 앱(2.0.2 까지)이 mid 없는 대메뉴를 모두 건너뛴다
            'home_mid' => self::HOME,
            // 첫 화면이 페이지인지 (1.1.0~, 앱의 '페이지로 보기'). 이 첫 화면은 플러그인이 앱용으로 그리므로 css 는 비어 있다
            'home_is_page' => true,
            'engine' => 'gnuboard',
            'engine_version' => defined('G5_GNUBOARD_VER') ? G5_GNUBOARD_VER : '',
            'api_version' => BoardMoa_Api::VERSION,
            'lang' => 'ko',
            'features' => array_values(array_unique($features)),
            'member' => BoardMoa_Api::profile(self::member()),
        );
    }

    /** 가로형 로고: 테마(모바일)·기본 이미지 폴더의 logo.png·logo.gif */
    private static function logo()
    {
        $dirs = array();
        if (defined('G5_THEME_PATH')) {
            if (defined('G5_THEME_MOBILE_PATH')) {
                $dirs[] = array(G5_THEME_MOBILE_PATH . '/' . G5_IMG_DIR, G5_THEME_URL . '/' . G5_MOBILE_DIR . '/' . G5_IMG_DIR);
            }
            $dirs[] = array(G5_THEME_PATH . '/' . G5_IMG_DIR, G5_THEME_URL . '/' . G5_IMG_DIR);
        }
        $dirs[] = array(G5_PATH . '/' . G5_IMG_DIR, G5_URL . '/' . G5_IMG_DIR);
        foreach ($dirs as $d) {
            foreach (array('logo.png', 'logo.gif', 'logo.jpg', 'm_logo.png') as $name) {
                if (is_file($d[0] . '/' . $name)) {
                    return $d[1] . '/' . $name;
                }
            }
        }
        return null;
    }

    private static function icon()
    {
        foreach (array('apple-touch-icon.png', 'favicon.png', 'favicon.ico') as $name) {
            if (is_file(G5_PATH . '/' . $name)) {
                return G5_URL . '/' . $name;
            }
        }
        return BoardMoa_Html::origin() . '/favicon.ico';
    }

    // ---- 메뉴

    /** 사이트 메뉴(관리자 → 환경설정 → 메뉴설정, 모바일 웹에서 보이는 것). 메뉴가 없으면 그룹·게시판 순서 */
    public static function menu()
    {
        $items = array();
        $placed = array();
        $menu = get_menu_db(G5_IS_MOBILE ? 1 : 0, true);
        foreach ((array)$menu as $top) {
            $children = array();
            foreach (isset($top['sub']) ? (array)$top['sub'] : array() as $sub) {
                if ($out = self::menuItem($sub['me_name'], $sub['ori_me_link'], $sub['me_target'], array(), $placed)) {
                    $children[] = $out;
                }
            }
            if ($out = self::menuItem($top['me_name'], $top['ori_me_link'], $top['me_target'], $children, $placed)) {
                $items[] = $out;
            }
        }
        if (!$menu) {
            $items = self::groupMenu($placed);
        }
        return array('menus' => $items ? array(array('id' => 'main_menu', 'title' => BoardMoa_Text::t('메뉴'), 'items' => $items)) : array());
    }

    /** 메뉴 설정이 없는 사이트: 그룹(묶음) → 게시판 */
    private static function groupMenu(&$placed)
    {
        $groups = array();
        foreach (self::all() as $b) {
            if (!$b['bo_use_search'] && !self::canList($b)) {
                continue;
            }
            $groups[$b['gr_id']]['title'] = $b['gr_subject'] !== null ? $b['gr_subject'] : $b['gr_id'];
            $groups[$b['gr_id']]['boards'][] = $b;
        }
        $items = array();
        foreach ($groups as $g) {
            $children = array();
            foreach ($g['boards'] as $b) {
                if ($out = self::menuItem(self::title($b), G5_BBS_URL . '/board.php?bo_table=' . $b['bo_table'], '', array(), $placed)) {
                    $children[] = $out;
                }
            }
            if ($children) {
                $items[] = array('title' => BoardMoa_Html::text($g['title']), 'mid' => null, 'module' => null, 'grant' => null, 'url' => null, 'open_window' => false, 'children' => $children);
            }
        }
        return $items;
    }

    /** 메뉴 한 줄: 볼 수 없는 게시판은 빼고, 아래에 볼 것이 남은 경우에만 제목만 있는 묶음(mid null)으로 남긴다 */
    private static function menuItem($title, $link, $target, array $children, &$placed)
    {
        $title = BoardMoa_Html::text($title);
        $group = array('title' => $title, 'mid' => null, 'module' => null, 'grant' => null, 'url' => null, 'open_window' => false, 'children' => $children);
        $link = trim((string)$link);
        $found = $link !== '' ? self::target(BoardMoa_Html::absolute($link)) : null;
        if ($found === null) {
            if ($link === '' || $link === '#' || strpos($link, '#') === 0 || stripos($link, 'javascript:') === 0) {
                return $children ? $group : null;
            }
            $url = BoardMoa_Html::absolute($link);
            // 같은 사이트의 그룹 화면(group.php) 등 앱 화면이 없는 곳은 묶음 제목으로만
            if (self::sameSite($url) && preg_match('#/' . preg_quote(G5_BBS_DIR, '#') . '/group\.php#', $url)) {
                return $children ? $group : null;
            }
            return array('title' => $title, 'mid' => null, 'module' => null, 'grant' => null, 'url' => $url, 'open_window' => $target === '_blank', 'children' => $children);
        }
        if ($found === false || isset($placed[$found['mid']])) {
            return $children ? $group : null; // 볼 수 없거나 이미 넣은 게시판
        }
        $placed[$found['mid']] = true;
        $grant = null;
        if ($found['module'] === 'board') {
            $g = self::grant(self::get($found['mid']));
            $grant = array('view' => $g['view'], 'write_document' => $g['write_document'], 'write_comment' => $g['write_comment']);
        }
        return array(
            'title' => $title !== '' ? $title : $found['title'],
            'mid' => $found['mid'],
            'module' => $found['module'],
            'grant' => $grant,
            'url' => $found['url'],
            'open_window' => false,
            'children' => $children,
        );
    }

    private static function sameSite($url)
    {
        $host = strtolower((string)parse_url($url, PHP_URL_HOST));
        $site = strtolower((string)parse_url(G5_URL, PHP_URL_HOST));
        return $host !== '' && preg_replace('/^www\./', '', $host) === preg_replace('/^www\./', '', $site);
    }

    /**
     * 같은 사이트 주소가 가리키는 게시판·글·내용 페이지.
     * 반환: ['mid', 'module', 'title', 'url', 'document_srl'] · false(그누보드 게시판인데 목록을 볼 수 없음) · null(앱 화면 아님)
     */
    private static function target($url)
    {
        if (!self::sameSite($url)) {
            return null;
        }
        $path = (string)parse_url($url, PHP_URL_PATH);
        parse_str((string)parse_url($url, PHP_URL_QUERY), $q);
        $basePath = rtrim((string)parse_url(G5_URL, PHP_URL_PATH), '/');
        if ($basePath !== '' && strpos($path, $basePath) === 0) {
            $path = substr($path, strlen($basePath));
        }
        $boTable = '';
        $wrId = 0;
        $coId = '';
        if (preg_match('#^/' . preg_quote(G5_BBS_DIR, '#') . '/board\.php$#', $path) && !empty($q['bo_table'])) {
            $boTable = (string)$q['bo_table'];
            $wrId = isset($q['wr_id']) ? (int)$q['wr_id'] : 0;
        } elseif (preg_match('#^/' . preg_quote(G5_BBS_DIR, '#') . '/content\.php$#', $path) && !empty($q['co_id'])) {
            $coId = (string)$q['co_id'];
        } elseif (preg_match('#^/content/([A-Za-z0-9_]+)/?$#', $path, $m)) {
            $coId = $m[1]; // 짧은 주소
        } elseif (preg_match('#^/([A-Za-z0-9_]{1,20})(?:/([0-9]+))?/?$#', $path, $m) && self::get($m[1])) {
            $boTable = $m[1]; // 짧은 주소 (/free, /free/12)
            $wrId = isset($m[2]) ? (int)$m[2] : 0;
        }
        if ($boTable !== '') {
            $b = self::get(preg_replace('/[^A-Za-z0-9_]/', '', $boTable));
            if (!$b) {
                return null;
            }
            if (!self::canList($b)) {
                return false;
            }
            return array('mid' => $b['bo_table'], 'module' => 'board', 'title' => self::title($b), 'url' => G5_BBS_URL . '/board.php?bo_table=' . $b['bo_table'], 'document_srl' => $wrId ?: null);
        }
        if ($boTable === '' && $coId === '' && ($path === '' || $path === '/' || $path === '/index.php') && !$q) {
            return array('mid' => self::HOME, 'module' => 'page', 'title' => BoardMoa_Html::text($GLOBALS['config']['cf_title']), 'url' => G5_URL . '/', 'document_srl' => null);
        }
        if ($coId !== '') {
            $co = self::content($coId);
            if (!$co) {
                return null;
            }
            return array('mid' => self::CONTENT_PREFIX . $co['co_id'], 'module' => 'page', 'title' => BoardMoa_Html::text($co['co_subject']), 'url' => G5_BBS_URL . '/content.php?co_id=' . $co['co_id'], 'document_srl' => null);
        }
        return null;
    }

    private static function content($coId)
    {
        global $g5;
        $coId = preg_replace('/[^A-Za-z0-9_]/', '', (string)$coId);
        if ($coId === '') {
            return null;
        }
        $row = sql_fetch(" select * from {$g5['content_table']} where co_id = '$coId' ");
        return !empty($row['co_id']) ? $row : null;
    }

    /** 같은 사이트 주소가 가리키는 게시판·글 (볼 수 없으면 null) — 본문 링크·resolve */
    public static function locate($url)
    {
        static $cache = array();
        if (!array_key_exists($url, $cache)) {
            $found = self::target($url);
            $cache[$url] = $found ? array('mid' => $found['mid'], 'module' => $found['module'], 'title' => $found['title'], 'document_srl' => $found['document_srl']) : null;
        }
        return $cache[$url];
    }

    // ---- 모아 보기

    /** 메뉴에 있고 목록을 볼 수 있는 게시판 (메뉴 순서). 메뉴가 없으면 검색 사용 게시판 */
    public static function visibleBoards()
    {
        $menu = self::menu();
        $mids = array();
        $walk = function ($items) use (&$walk, &$mids) {
            foreach ($items as $item) {
                if ($item['module'] === 'board' && $item['mid'] !== null) {
                    $mids[$item['mid']] = true;
                }
                $walk($item['children']);
            }
        };
        foreach ($menu['menus'] as $m) {
            $walk($m['items']);
        }
        $out = array();
        foreach (array_keys($mids) as $mid) {
            if ($b = self::get($mid)) {
                $out[$mid] = $b;
            }
        }
        return $out;
    }

    public static function feed()
    {
        global $g5;
        $boards = self::visibleBoards();
        $mids = array_filter(array_map('trim', explode(',', (string)BoardMoa_Api::param('mids', ''))));
        if ($mids) {
            $boards = array_intersect_key($boards, array_flip($mids));
        }
        $count = min(50, max(5, BoardMoa_Api::intParam('list_count', 20)));
        $page = min(self::MAX_FEED_PAGE, max(1, BoardMoa_Api::intParam('page', 1)));
        $need = $page * $count + 1;
        $rows = array();
        foreach ($boards as $b) {
            // 그누보드 첫 화면(모바일 index.php)의 최신글처럼 게시판의 '전체 검색 사용'과 상관없이. 본인확인 게시판은 첫 화면처럼 뺀다
            if ($b['bo_use_cert'] !== '' && self::adminOf($b) === '') {
                continue;
            }
            $table = $g5['write_prefix'] . $b['bo_table'];
            $result = sql_query(" select * from `$table` where wr_is_comment = 0 order by wr_datetime desc, wr_id desc limit $need ", false);
            while ($result && ($row = sql_fetch_array($result))) {
                $s = self::summary($b, $row);
                $s['mid'] = $b['bo_table'];
                $s['board_title'] = self::title($b);
                $rows[] = array('time' => BoardMoa_Html::timestamp($row['wr_datetime']), 'summary' => $s);
            }
        }
        usort($rows, function ($a, $b) {
            return $b['time'] - $a['time'];
        });
        $documents = array();
        foreach (array_slice($rows, ($page - 1) * $count, $count) as $row) {
            $documents[] = $row['summary'];
        }
        $more = count($rows) > $page * $count;
        return array('documents' => $documents, 'page' => $page, 'total_pages' => $more ? $page + 1 : $page);
    }

    // ---- 게시판 목록

    private static function categories($b)
    {
        if (!$b['bo_use_category']) {
            return array();
        }
        $out = array();
        foreach (explode('|', (string)$b['bo_category_list']) as $name) {
            $name = trim($name);
            if ($name !== '') {
                $out[] = $name;
            }
        }
        return $out;
    }

    private static function categorySrl($b, $caName)
    {
        $i = array_search((string)$caName, self::categories($b), true);
        return $i === false ? 0 : $i + 1;
    }

    private static function pageRows($b)
    {
        $rows = (int)(G5_IS_MOBILE ? $b['bo_mobile_page_rows'] : $b['bo_page_rows']);
        return $rows > 0 ? $rows : 15;
    }

    private static function style($b)
    {
        $skin = (G5_IS_MOBILE && $b['bo_mobile_skin']) ? $b['bo_mobile_skin'] : $b['bo_skin'];
        if (stripos($skin, 'gallery') !== false) {
            return 'gallery';
        }
        if (stripos($skin, 'webzine') !== false) {
            return 'webzine';
        }
        return 'list';
    }

    /** board 응답의 board */
    public static function info($b, $grant = null)
    {
        global $g5;
        $grant = $grant ?: self::grant($b);
        $categories = array();
        $table = $g5['write_prefix'] . $b['bo_table'];
        foreach (self::categories($b) as $i => $name) {
            $row = sql_fetch(" select count(*) as cnt from `$table` where wr_is_comment = 0 and ca_name = '" . sql_real_escape_string($name) . "' ", false);
            $categories[] = array('category_srl' => $i + 1, 'parent_srl' => 0, 'title' => $name, 'document_count' => (int)$row['cnt'], 'writable' => true);
        }
        $guest = !self::member();
        return array_merge(array(
            'mid' => $b['bo_table'],
            'title' => self::title($b),
            'style' => self::style($b),
            'columns' => array('read_count' => true, 'vote_count' => (bool)$b['bo_use_good']),
            'use_secret' => (int)$b['bo_use_secret'] > 0,
            'categories' => $categories,
            'grant' => $grant,
            'upload' => array('allowed' => false, 'max_file_size' => null, 'max_total_size' => null),
            'category_required' => (bool)$b['bo_use_category'] && count($categories) > 0,
            'extra_keys' => array(),
            // 댓글 단추 문구: 그누보드 기본 스킨의 낱말 (그누보드는 한국어만이라 앱 언어가 한국어일 때만, 그 밖에는 앱 문구)
            'labels' => BoardMoa_Text::code() === 'ko' ? array('comment_reply' => '답변', 'comment_edit' => '수정', 'comment_delete' => '삭제') : (object)array(),
            'captcha' => array('document' => false, 'comment' => false),
            'captcha_widget' => null,
            'write_url' => G5_BBS_URL . '/write.php?bo_table=' . $b['bo_table'],
            'guest_fields' => null,
            'guest_comment_fields' => null,
            'guest_certify_fields' => $guest ? array('password') : null,
        ), BoardMoa_Write::boardInfo($b, $grant));
    }

    public static function board()
    {
        global $g5;
        $b = self::find(BoardMoa_Api::param('mid'));
        self::context($b);
        $grant = self::grant($b);
        $table = $g5['write_prefix'] . $b['bo_table'];
        $perPage = self::pageRows($b);
        $page = min(10000, max(1, BoardMoa_Api::intParam('page', 1)));
        $where = 'wr_is_comment = 0';
        $search = false;
        $caName = '';
        $catSrl = BoardMoa_Api::intParam('category', BoardMoa_Api::intParam('category_srl', 0));
        $cats = self::categories($b);
        if ($catSrl > 0 && isset($cats[$catSrl - 1])) {
            $caName = $cats[$catSrl - 1];
        }
        $keyword = trim((string)BoardMoa_Api::param('search_keyword', ''));
        if ($keyword !== '' || $caName !== '') {
            // 웹 목록 검색과 같은 엔진 함수 (댓글 내용도 찾아 원글로 묶는다)
            $fields = array('title' => 'wr_subject', 'content' => 'wr_content', 'title_content' => 'wr_subject||wr_content', 'comment' => 'wr_content',
                'nick_name' => 'wr_name,1', 'user_id' => 'mb_id,1');
            $target = (string)BoardMoa_Api::param('search_target', 'title_content');
            $sfl = isset($fields[$target]) ? $fields[$target] : 'wr_subject||wr_content';
            $where = get_sql_search($caName, $keyword !== '' ? $sfl : '', $keyword !== '' ? get_search_string($keyword) : '', 'and');
            $search = true;
        }
        // 정렬: 게시판 설정(bo_sort_field), 없으면 웹 기본(글 번호·답글 순서)
        $order = 'wr_num, wr_reply';
        if ($b['bo_sort_field'] && function_exists('get_board_sort_fields')) {
            foreach (get_board_sort_fields($b) as $f) {
                if ($f[0] === $b['bo_sort_field']) {
                    $order = $b['bo_sort_field'];
                }
            }
        }
        $notices = array();
        $noticeIds = array();
        foreach (explode(',', (string)$b['bo_notice']) as $id) {
            if ((int)$id > 0) {
                $noticeIds[] = (int)$id;
            }
        }
        if (!$search && $noticeIds && $page === 1) {
            $result = sql_query(" select * from `$table` where wr_id in (" . implode(',', $noticeIds) . ") ");
            $byId = array();
            while ($row = sql_fetch_array($result)) {
                $byId[$row['wr_id']] = $row;
            }
            foreach ($noticeIds as $id) {
                if (isset($byId[$id])) {
                    $s = self::summary($b, $byId[$id]);
                    $s['is_notice'] = true;
                    $notices[] = $s;
                }
            }
        }
        if ($search) {
            $row = sql_fetch(" select count(distinct wr_parent) as cnt from `$table` where $where ");
            $total = (int)$row['cnt'];
            $ids = array();
            $result = sql_query(" select distinct wr_parent from `$table` where $where order by $order limit " . (($page - 1) * $perPage) . ", $perPage ");
            while ($row = sql_fetch_array($result)) {
                $ids[] = (int)$row['wr_parent'];
            }
            $rows = array();
            if ($ids) {
                $result = sql_query(" select * from `$table` where wr_id in (" . implode(',', $ids) . ") ");
                $byId = array();
                while ($row = sql_fetch_array($result)) {
                    $byId[$row['wr_id']] = $row;
                }
                foreach ($ids as $id) {
                    if (isset($byId[$id])) {
                        $rows[] = $byId[$id];
                    }
                }
            }
        } else {
            $exclude = $noticeIds ? ' and wr_id not in (' . implode(',', $noticeIds) . ')' : '';
            $row = sql_fetch(" select count(*) as cnt from `$table` where wr_is_comment = 0 $exclude ");
            $total = (int)$row['cnt'];
            $rows = array();
            $result = sql_query(" select * from `$table` where wr_is_comment = 0 $exclude order by $order limit " . (($page - 1) * $perPage) . ", $perPage ");
            while ($row = sql_fetch_array($result)) {
                $rows[] = $row;
            }
        }
        $documents = array();
        foreach ($rows as $row) {
            $s = self::summary($b, $row);
            if (!$search && strlen($row['wr_reply']) > 0) {
                $s['reply_depth'] = strlen($row['wr_reply']); // 답변글 (wr_num 이 같고 wr_reply 가 A, AA … 순)
            }
            $documents[] = $s;
        }
        return array(
            'board' => self::info($b, $grant),
            'notices' => $notices,
            'documents' => $documents,
            'page' => $page,
            'total_pages' => max(1, (int)ceil($total / $perPage)),
            'total_count' => $total,
        );
    }

    // ---- 글

    /** 회원 아이디 → 회원 번호 (작성자 이름 메뉴용) */
    public static function mbNo($mbId)
    {
        global $g5;
        $mbId = (string)$mbId;
        if ($mbId === '') {
            return 0;
        }
        if (!isset(self::$mbNo[$mbId])) {
            $row = sql_fetch(" select mb_no from {$g5['member_table']} where mb_id = '" . sql_real_escape_string($mbId) . "' ");
            self::$mbNo[$mbId] = isset($row['mb_no']) ? (int)$row['mb_no'] : 0;
        }
        return self::$mbNo[$mbId];
    }

    public static function isMine($row)
    {
        $id = self::mbId();
        return $id !== '' && (string)$row['mb_id'] === $id;
    }

    /**
     * 답변글을 쓸 수 있는가 (write.php w=r 과 같은 검사: 답변 레벨, 공지·댓글 아님, 비밀글은 회원 글이면 글쓴이·관리자, 비회원 비밀글은 관리자,
     * 포인트, 답변 깊이 10단계). write_update.php 는 비밀글 검사를 하지 않아 앱 요청에서는 여기서 막는다
     */
    public static function canReply($b, $row)
    {
        $admin = self::adminOf($b) !== '';
        if (self::level() < (int)$b['bo_reply_level'] || (int)$row['wr_is_comment'] || strlen((string)$row['wr_reply']) >= 10) {
            return false;
        }
        if (in_array((string)$row['wr_id'], array_map('trim', explode(',', (string)$b['bo_notice'])), true)) {
            return false;
        }
        if (self::isSecret($row) && !$admin && ($row['mb_id'] === '' || !self::isMine($row))) {
            return false;
        }
        $m = self::member();
        return $admin || ($m ? (int)$m['mb_point'] : 0) + (int)$b['bo_write_point'] >= 0;
    }

    public static function isSecret($row)
    {
        return strpos((string)$row['wr_option'], 'secret') !== false;
    }

    /**
     * 비밀글을 이 사람이 바로 볼 수 있는가 (board.php): 자기 글·관리자, 또는 자기 비밀글에 달린 답변글.
     * 비회원 글은 비밀번호를 넣어야 한다 (password_view).
     */
    public static function secretOpen($b, $row)
    {
        global $g5;
        if (!self::isSecret($row) || self::isMine($row) || self::adminOf($b) !== '') {
            return true;
        }
        $id = self::mbId();
        if ($row['wr_reply'] !== '' && $id !== '') {
            $table = $g5['write_prefix'] . $b['bo_table'];
            $origin = sql_fetch(" select mb_id from `$table` where wr_num = '" . (int)$row['wr_num'] . "' and wr_reply = '' and wr_is_comment = 0 ");
            if (isset($origin['mb_id']) && $origin['mb_id'] === $id) {
                return true;
            }
        }
        return false;
    }

    /** 글읽기 포인트를 받지 않는 경우 (board.php: 자기 글, 읽기 레벨 1 게시판에서 같은 IP 의 비회원 글) */
    private static function readPointExempt($b, $row)
    {
        return self::isMine($row) || (!self::member() && (int)$b['bo_read_level'] === 1 && $row['wr_ip'] === BoardMoa_Api::ip());
    }

    /** 글읽기 포인트가 모자라 웹이 막는가 (비회원은 포인트 0 으로 본다) */
    public static function readPointBlocked($b, $row)
    {
        global $config;
        if (empty($config['cf_use_point']) || !(int)$b['bo_read_point'] || self::readPointExempt($b, $row)) {
            return false;
        }
        $m = self::member();
        return ($m ? (int)$m['mb_point'] : 0) + (int)$b['bo_read_point'] < 0;
    }

    /** 문서요약 */
    public static function summary($b, $row)
    {
        // 비회원이 포인트 때문에 읽을 수 없는 글은 요약·썸네일도 주지 않는다 (회원은 읽을 권한이 있고 포인트만 든다)
        $readable = self::canRead($b) && self::secretOpen($b, $row) && (self::member() || !self::readPointBlocked($b, $row));
        $thumb = null;
        if ($readable && (int)$row['wr_file'] + (stripos((string)$row['wr_content'], '<img') !== false ? 1 : 0) > 0) {
            $thumb = self::thumbnail($b, $row);
        }
        return array(
            'document_srl' => (int)$row['wr_id'],
            'title' => html_entity_decode((string)$row['wr_subject'], ENT_QUOTES, 'UTF-8'),
            'author' => (string)$row['wr_name'],
            'author_image' => $row['mb_id'] !== '' ? BoardMoa_Api::avatar($row['mb_id']) : null,
            'author_srl' => self::mbNo($row['mb_id']),
            'is_mine' => self::isMine($row),
            'regdate' => BoardMoa_Html::iso($row['wr_datetime']),
            'last_update' => BoardMoa_Html::iso($row['wr_last'] !== '' ? $row['wr_last'] : $row['wr_datetime']),
            'category_srl' => self::categorySrl($b, $row['ca_name']),
            'comment_count' => (int)$row['wr_comment'],
            'read_count' => (int)$row['wr_hit'],
            'vote_count' => $b['bo_use_good'] ? (int)$row['wr_good'] : null,
            'is_notice' => in_array((string)$row['wr_id'], array_map('trim', explode(',', (string)$b['bo_notice'])), true),
            'is_secret' => self::isSecret($row),
            'has_files' => (int)$row['wr_file'] > 0,
            'thumbnail' => $thumb,
            'summary' => $readable ? BoardMoa_Html::summary(conv_content($row['wr_content'], strpos($row['wr_option'], 'html') !== false ? 1 : 0)) : '',
        );
    }

    /** 목록 썸네일: 웹 목록·갤러리와 같은 엔진 함수 (첨부 사진 → 본문 사진, 비밀글은 없음) */
    private static function thumbnail($b, $row)
    {
        if (!function_exists('get_list_thumbnail')) {
            include_once G5_LIB_PATH . '/thumbnail.lib.php';
        }
        $w = (int)(G5_IS_MOBILE ? $b['bo_mobile_gallery_width'] : $b['bo_gallery_width']) ?: 300;
        $h = (int)(G5_IS_MOBILE ? $b['bo_mobile_gallery_height'] : $b['bo_gallery_height']) ?: 225;
        $t = get_list_thumbnail($b['bo_table'], $row['wr_id'], $w, $h, false, true);
        if (!empty($t['src'])) {
            return BoardMoa_Html::absolute($t['src']);
        }
        return !empty($t['ori']) ? BoardMoa_Html::absolute($t['ori']) : null;
    }

    /** 글 행 (댓글이 아닌 것). 없으면 404 */
    public static function row($b, $wrId)
    {
        global $g5;
        $wrId = (int)$wrId;
        if ($wrId <= 0) {
            throw new BoardMoa_Error(400, 'missing_document_srl', 'document_srl is required', true);
        }
        $row = sql_fetch(" select * from `{$g5['write_prefix']}{$b['bo_table']}` where wr_id = '$wrId' ");
        if (empty($row['wr_id']) || (int)$row['wr_is_comment'] !== 0) {
            throw new BoardMoa_Error(404, 'document_not_found', '없는 글입니다.');
        }
        return $row;
    }

    /** 비회원 비밀글을 이번 요청에서 비밀번호로 열었는가 (document POST password) */
    private static function unlockedByPassword($row)
    {
        $password = (string)BoardMoa_Api::param('password', '');
        if ($password === '' || $row['mb_id'] !== '') {
            return false;
        }
        BoardMoa_Write::throttle();
        if (!check_password(BoardMoa_Engine::escape($password), $row['wr_password'])) {
            BoardMoa_Write::failed();
            throw new BoardMoa_Error(403, 'wrong_password', '비밀번호가 맞지 않습니다.');
        }
        return true;
    }

    /** 첨부 파일 */
    private static function files($b, $row)
    {
        global $g5;
        $out = array();
        $result = sql_query(" select * from {$g5['board_file_table']} where bo_table = '{$b['bo_table']}' and wr_id = '" . (int)$row['wr_id'] . "' order by bf_no ");
        while ($f = sql_fetch_array($result)) {
            $image = in_array((int)$f['bf_type'], array(1, 2, 3, 18), true) || preg_match('/\.(jpe?g|png|gif|webp)$/i', (string)$f['bf_file']);
            $url = $f['bf_fileurl'] !== '' ? $f['bf_fileurl'] : G5_DATA_URL . '/file/' . $b['bo_table'] . '/' . $f['bf_file'];
            $out[] = array(
                'file_srl' => (int)$f['bf_no'] + 1,
                'name' => (string)$f['bf_source'],
                'size' => (int)$f['bf_filesize'],
                'is_image' => (bool)$image,
                'image_url' => $image ? BoardMoa_Html::absolute($url) : null,
                'download' => array('r' => 'file', 'mid' => $b['bo_table'], 'document_srl' => (int)$row['wr_id'], 'file_srl' => (int)$f['bf_no'] + 1),
            );
        }
        return $out;
    }

    /** 본문 HTML: 웹 보기 화면처럼 첨부 사진을 위에, 그다음 본문 (conv_content, {이미지:n} 자리) */
    private static function contentHtml($b, $row, array $files)
    {
        $html = strpos($row['wr_option'], 'html1') !== false ? 1 : (strpos($row['wr_option'], 'html2') !== false ? 2 : 0);
        $content = conv_content($row['wr_content'], $html);
        $images = array();
        foreach ($files as $f) {
            if ($f['is_image']) {
                $images[$f['file_srl'] - 1] = '<img src="' . htmlspecialchars($f['image_url'], ENT_QUOTES, 'UTF-8') . '" alt="">';
            }
        }
        $inline = array();
        $content = preg_replace_callback('/{이미지\:([0-9]+)[:]?([^}]*)}/iu', function ($m) use ($images, &$inline) {
            $n = (int)$m[1];
            $inline[$n] = true;
            return isset($images[$n]) ? $images[$n] : '';
        }, $content);
        $top = '';
        foreach ($images as $n => $img) {
            if (!isset($inline[$n])) {
                $top .= '<p>' . $img . '</p>';
            }
        }
        return BoardMoa_Html::content($top . $content) . self::signature($b, $row) . self::linkList($row);
    }

    /** 서명 (view.php: 게시판 '서명 사용'이고 회원 글이면 회원 서명을 본문 아래에) */
    private static function signature($b, $row)
    {
        if (!$b['bo_use_signature'] || $row['mb_id'] === '') {
            return '';
        }
        $mb = get_member($row['mb_id'], 'mb_signature');
        if (empty($mb['mb_signature'])) {
            return '';
        }
        return '<hr><div class="bh-signature">' . BoardMoa_Html::content(conv_content($mb['mb_signature'], 1)) . '</div>';
    }

    /** 관련 링크 (웹 보기 스킨의 '관련링크', 링크 1·2) */
    private static function linkList($row)
    {
        $items = '';
        $count = defined('G5_LINK_COUNT') ? (int)G5_LINK_COUNT : 2;
        for ($i = 1; $i <= $count; $i++) {
            $link = isset($row['wr_link' . $i]) ? trim((string)$row['wr_link' . $i]) : '';
            if ($link === '') {
                continue;
            }
            $href = set_http($link);
            if (!preg_match('#^https?://#i', $href)) {
                continue;
            }
            $items .= '<li><a href="' . htmlspecialchars($href, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars(cut_str($link, 70, '…'), ENT_QUOTES, 'UTF-8') . '</a></li>';
        }
        return $items === '' ? '' : '<hr><p><strong>' . htmlspecialchars(BoardMoa_Text::t('관련 링크'), ENT_QUOTES, 'UTF-8') . '</strong></p><ul class="bh-links">' . $items . '</ul>';
    }

    /** 글 아래 기능 (추천·비추천·스크랩) */
    private static function actions($b, $row)
    {
        global $g5;
        $member = self::member();
        $my = 0;
        $scrapped = false;
        if ($member) {
            $good = sql_fetch(" select bg_flag from {$g5['board_good_table']} where bo_table = '{$b['bo_table']}' and wr_id = '" . (int)$row['wr_id'] . "' and mb_id = '" . sql_real_escape_string($member['mb_id']) . "' and bg_flag in ('good', 'nogood') ");
            if (!empty($good['bg_flag'])) {
                $my = $good['bg_flag'] === 'good' ? 1 : -1;
            }
            $scrap = sql_fetch(" select ms_id from {$g5['scrap_table']} where mb_id = '" . sql_real_escape_string($member['mb_id']) . "' and bo_table = '{$b['bo_table']}' and wr_id = '" . (int)$row['wr_id'] . "' ");
            $scrapped = !empty($scrap['ms_id']);
        }
        // view.php: 추천·스크랩 단추는 회원에게만
        return array(
            'vote_up' => array('enabled' => (bool)$b['bo_use_good'] && $member !== null, 'count' => (int)$row['wr_good'], 'public' => false),
            'vote_down' => array('enabled' => (bool)$b['bo_use_nogood'] && $member !== null, 'count' => (int)$row['wr_nogood'], 'public' => false),
            'my_vote' => $my,
            'can_cancel_vote' => false,
            'is_mine' => self::isMine($row),
            'can_scrap' => $member !== null,
            'can_declare' => false,
            'scrapped' => $scrapped,
        );
    }

    public static function document()
    {
        global $g5, $config;
        $b = self::find(BoardMoa_Api::param('mid'));
        $row = self::row($b, BoardMoa_Api::intParam('document_srl'));
        self::context($b, $row['wr_id']);
        if (!self::canRead($b)) {
            throw self::readDenied($b);
        }
        $grant = self::grant($b);
        $admin = self::adminOf($b);
        $mine = self::isMine($row);
        $summary = self::summary($b, $row);
        // 비회원 글은 비회원이 비밀번호로 고치고 지운다 (delete.php·write_update.php 는 회원에게는 자기 글만 허락한다)
        $passwordManaged = $row['mb_id'] === '' && !self::member();
        $unlocked = false;
        if (!self::secretOpen($b, $row)) {
            $unlocked = self::unlockedByPassword($row);
            if (!$unlocked) {
                return self::detail($summary, array(
                    'permanent_url' => get_pretty_url($b['bo_table'], $row['wr_id']),
                    'password_edit' => $passwordManaged,
                    'password_view' => $row['mb_id'] === '',
                    'board' => self::info($b, $grant),
                ));
            }
        }
        if (self::chargeRead($b, $row)) {
            $summary['read_count'] = (int)$row['wr_hit'];
        }
        $files = self::files($b, $row);
        $summary['summary'] = BoardMoa_Html::summary(conv_content($row['wr_content'], strpos($row['wr_option'], 'html') !== false ? 1 : 0));
        $editable = ($mine || $admin !== '') && !$unlocked;
        return self::detail($summary, array(
            'content_html' => self::contentHtml($b, $row, $files),
            'files' => $files,
            'permanent_url' => get_pretty_url($b['bo_table'], $row['wr_id']),
            'can_comment' => $grant['write_comment'],
            // 비밀번호로 연 비밀글: 앱은 댓글을 쓸 때 그 비밀번호를 document_password 로 같이 보낸다 (기능 unlocked_comment)
            'comment_document_password' => $unlocked && $grant['write_comment'],
            'can_reply' => !$unlocked && self::canReply($b, $row),
            'reply_title' => html_entity_decode((string)$row['wr_subject'], ENT_QUOTES, 'UTF-8'),
            'reply_secret' => self::isSecret($row),
            'can_edit' => $editable,
            'can_delete' => $editable,
            'password_edit' => $passwordManaged,
            'board' => self::info($b, $grant),
            'actions' => self::actions($b, $row),
            'comments' => self::commentPage($b, $row, $unlocked),
        ));
    }

    /**
     * 조회수·읽기 포인트 (board.php: 한 세션에 한 번, 포인트가 모자라면 비회원도 못 읽는다). 이 접속에서 처음 읽는 글이면 처리하고 참.
     * 글 보기뿐 아니라 댓글·첨부 내려받기·추천도 먼저 거친다: 웹은 글을 읽은(포인트를 낸) 세션에서만 이것들을 준다(ss_view_…)
     */
    public static function chargeRead($b, array &$row)
    {
        global $g5;
        if (BoardMoa_Store::viewed($b['bo_table'], $row['wr_id'])) {
            return false;
        }
        $member = self::member();
        if (self::readPointBlocked($b, $row)) {
            throw BoardMoa_Api::denied($member
                ? BoardMoa_Text::t('포인트가 모자라서 글을 읽을 수 없습니다. (보유 {0}, 글읽기 {1})', number_format($member['mb_point']), number_format($b['bo_read_point']))
                : BoardMoa_Text::t('이 게시판은 글을 읽을 때 포인트가 차감되어 로그인한 회원만 읽을 수 있습니다.'));
        }
        sql_query(" update `{$g5['write_prefix']}{$b['bo_table']}` set wr_hit = wr_hit + 1 where wr_id = '" . (int)$row['wr_id'] . "' ");
        $row['wr_hit']++;
        if (!self::readPointExempt($b, $row)) {
            insert_point($member ? $member['mb_id'] : '', $b['bo_read_point'], self::title($b) . ' ' . $row['wr_id'] . ' 글읽기', $b['bo_table'], $row['wr_id'], '읽기');
        }
        BoardMoa_Store::markViewed($b['bo_table'], $row['wr_id']);
        return true;
    }

    private static function detail(array $summary, array $values)
    {
        return array_merge($summary, array(
            'content_html' => null, 'files' => array(), 'extra_vars' => array(), 'permanent_url' => null,
            'can_comment' => false, 'can_reply' => false, 'can_edit' => false, 'can_delete' => false, 'password_edit' => false, 'password_view' => false,
            'actions' => null, 'comments' => array('items' => array(), 'page' => 1, 'total_pages' => 1, 'total_count' => 0),
        ), $values);
    }

    public static function comments()
    {
        $b = self::find(BoardMoa_Api::param('mid'));
        $row = self::row($b, BoardMoa_Api::intParam('document_srl'));
        self::context($b, $row['wr_id']);
        if (!self::canRead($b)) {
            throw self::readDenied($b);
        }
        $unlocked = false;
        if (!self::secretOpen($b, $row)) {
            $unlocked = self::unlockedByPassword($row);
            if (!$unlocked) {
                throw BoardMoa_Api::denied('비밀글입니다.');
            }
        }
        self::chargeRead($b, $row);
        return self::commentPage($b, $row, $unlocked);
    }

    /** 댓글 (view_comment.php: 모두 한 쪽, 비밀 댓글은 글쓴이·댓글쓴이·관리자만, 답글 달린 댓글은 관리자 말고 고치거나 지울 수 없다) */
    private static function commentPage($b, $row, $unlocked)
    {
        global $g5;
        $member = self::member();
        $id = self::mbId();
        $admin = self::adminOf($b);
        $canWrite = self::level() >= (int)$b['bo_comment_level'];
        $table = $g5['write_prefix'] . $b['bo_table'];
        $result = sql_query(" select * from `$table` where wr_parent = '" . (int)$row['wr_id'] . "' and wr_is_comment = 1 order by wr_comment, wr_comment_reply ");
        $list = array();
        while ($c = sql_fetch_array($result)) {
            $list[] = $c;
        }
        $items = array();
        $index = array(); // wr_comment|wr_comment_reply → 댓글 번호
        foreach ($list as $i => $c) {
            $index[$c['wr_comment'] . '|' . $c['wr_comment_reply']] = (int)$c['wr_id'];
            $own = $id !== '' && $c['mb_id'] === $id;
            $visible = !self::isSecret($c) || $admin !== '' || ($id !== '' && $row['mb_id'] === $id) || $own;
            $edit = false;
            $del = false;
            $passwordEdit = false;
            if ($canWrite || $admin !== '') {
                if ($member) {
                    $edit = $del = ($own || $admin !== '');
                } elseif ($c['mb_id'] === '') {
                    $passwordEdit = true;
                }
            }
            // 바로 다음 댓글이 이 댓글의 답글이면 (관리자 말고는) 고치기·지우기 없음
            if ($admin === '' && isset($list[$i + 1]) && $list[$i + 1]['wr_comment'] === $c['wr_comment']
                && substr($list[$i + 1]['wr_comment_reply'], 0, -1) === $c['wr_comment_reply'] && $list[$i + 1]['wr_comment_reply'] !== '') {
                $edit = $del = $passwordEdit = false;
            }
            $reply = (string)$c['wr_comment_reply'];
            $parent = $reply !== '' ? (isset($index[$c['wr_comment'] . '|' . substr($reply, 0, -1)]) ? $index[$c['wr_comment'] . '|' . substr($reply, 0, -1)] : 0) : 0;
            $items[] = array(
                'comment_srl' => (int)$c['wr_id'],
                'parent_srl' => $parent,
                'depth' => strlen($reply),
                'author' => (string)$c['wr_name'],
                'author_image' => $c['mb_id'] !== '' ? BoardMoa_Api::avatar($c['mb_id']) : null,
                'author_srl' => self::mbNo($c['mb_id']),
                'is_mine' => $own,
                'regdate' => BoardMoa_Html::iso($c['wr_datetime']),
                'is_secret' => self::isSecret($c),
                'content_html' => $visible ? BoardMoa_Html::content(conv_content($c['wr_content'], 0, 'wr_content')) : null,
                'vote_count' => 0,
                'can_delete' => $del,
                'can_edit' => $edit && $visible,
                'password_edit' => $passwordEdit,
                'files' => array(),
            );
        }
        return array('items' => $items, 'page' => 1, 'total_pages' => 1, 'total_count' => count($items));
    }

    // ---- 첨부 내려받기 (bbs/download.php 를 그대로: 레벨·포인트·횟수가 웹과 같다)

    public static function file()
    {
        $b = self::find(BoardMoa_Api::param('mid'));
        $row = self::row($b, BoardMoa_Api::intParam('document_srl'));
        self::context($b, $row['wr_id']);
        if (!self::canRead($b)) {
            throw self::readDenied($b);
        }
        if (!self::secretOpen($b, $row) && !self::unlockedByPassword($row)) {
            throw BoardMoa_Api::denied('비밀글입니다.');
        }
        $no = BoardMoa_Api::intParam('file_srl') - 1;
        if ($no < 0) {
            throw new BoardMoa_Error(404, 'not_found', '없는 파일입니다.');
        }
        self::chargeRead($b, $row);
        // 웹은 글을 읽은 세션에서만 내려받게 한다(ss_view_…): 앱은 위에서 같은 읽기 권한을 확인했다
        set_session('ss_view_' . $b['bo_table'] . '_' . $row['wr_id'], true);
        BoardMoa_Engine::input(array('bo_table' => $b['bo_table'], 'wr_id' => (int)$row['wr_id'], 'no' => $no,
            'nonce' => download_file_nonce_key($b['bo_table'], $row['wr_id']), 'js' => 'on'), true);
        // 파일 앞에 섞이지 않게: 지금까지 찍힌 것(common.php 의 경고 등)은 버린다
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        ob_start();
        try {
            $run = BoardMoa_Engine::run(G5_BBS_PATH . '/download.php');
        } catch (BoardMoa_Alert $e) {
            throw new BoardMoa_Error(self::member() ? 403 : 401, 'not_permitted', $e->getMessage(), true);
        }
        echo $run['output'];
        return null;
    }

    // ---- 내용 페이지 (bbs/content.php)

    /** 첫 화면: 메뉴의 게시판마다 최신 글 5개 (그누보드 기본 첫 화면의 최신글처럼, 목록을 볼 수 있는 곳만) */
    private static function homePage()
    {
        global $g5, $config;
        $html = '';
        foreach (self::visibleBoards() as $b) {
            if ($b['bo_use_cert'] !== '' && self::adminOf($b) === '') {
                continue;
            }
            $table = $g5['write_prefix'] . $b['bo_table'];
            $result = sql_query(" select wr_id, wr_subject, wr_datetime, wr_comment, wr_option from `$table` where wr_is_comment = 0 order by wr_num, wr_reply limit 5 ", false);
            $items = '';
            while ($result && ($row = sql_fetch_array($result))) {
                $url = G5_BBS_URL . '/board.php?bo_table=' . $b['bo_table'] . '&wr_id=' . (int)$row['wr_id'];
                $items .= '<li><a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars(html_entity_decode((string)$row['wr_subject'], ENT_QUOTES, 'UTF-8'), ENT_QUOTES, 'UTF-8') . '</a>'
                    . ((int)$row['wr_comment'] ? ' <small>[' . (int)$row['wr_comment'] . ']</small>' : '') . ' <small>' . substr($row['wr_datetime'], 5, 5) . '</small></li>';
            }
            if ($items === '') {
                continue;
            }
            $html .= '<h3><a href="' . htmlspecialchars(G5_BBS_URL . '/board.php?bo_table=' . $b['bo_table'], ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars(self::title($b), ENT_QUOTES, 'UTF-8') . '</a></h3><ul>' . $items . '</ul>';
        }
        return array(
            'mid' => self::HOME,
            'title' => BoardMoa_Html::text($config['cf_title']),
            'page_type' => 'widget',
            'content_html' => BoardMoa_Html::content($html),
            'web_url' => G5_URL . '/',
        );
    }

    public static function page()
    {
        $page = self::pageContent();
        if (BoardMoa_Api::param('with_css')) {
            $page['css'] = array();
            // 첫 화면은 웹과 같게 테마의 index.php 를 실행해 만든다 (못 만들면 앱용 첫 화면)
            if ($page['mid'] === self::HOME && ($web = self::renderHome())) {
                $page = array_merge($page, $web);
            }
        }
        return $page;
    }

    /** 첫 화면을 웹과 같게. 최신글 위젯은 권한을 보지 않으므로 볼 수 없는 게시판으로 가는 링크를 지운다 */
    private static function renderHome()
    {
        // 테마 끝의 html_end() 가 버퍼를 하나 닫고 그 바깥으로 찍으므로, 한 겹 더 받는다
        $level = ob_get_level();
        ob_start();
        try {
            $run = BoardMoa_Engine::run(G5_PATH . '/index.php');
        } catch (\Exception $e) {
            $run = null;
        } catch (\Throwable $e) {
            $run = null;
        }
        $output = '';
        while (ob_get_level() > $level) {
            $output = ob_get_clean() . $output;
        }
        if (!$run || !empty($run['redirect'])) {
            return null;
        }
        $output .= $run['output'];
        $visible = array();
        foreach (self::visibleBoards() as $b) {
            $visible[$b['bo_table']] = true;
        }
        $isHidden = function ($url) use ($visible) {
            $query = array();
            parse_str((string)parse_url($url, PHP_URL_QUERY), $query);
            $table = isset($query['bo_table']) && is_string($query['bo_table']) ? $query['bo_table'] : '';
            if ($table === '') {
                $parts = explode('/', trim((string)parse_url($url, PHP_URL_PATH), '/'));
                $table = (string)$parts[0];
            }
            return $table !== '' && self::get($table) && empty($visible[$table]);
        };
        try {
            return self::cleanWebPage($output, array('//main', '//*[@id="container"]', '//*[@id="wrapper"]'), $isHidden, array('BoardMoa_Html', 'absolute'));
        } catch (\Exception $e) {
            return null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * 웹 화면 HTML 에서 앱과 겹치거나 앱에서 쓸 수 없는 것을 빼 '페이지로 보기' 값으로 만든다 (XE 모듈 renderWebPage 와 같은 규칙).
     * 스크립트·입력 양식, 본문 바깥의 머리·메뉴·꼬리, 이 회원이 볼 수 없는 게시판으로 가는 링크(줄째)를 뺀다. 본문을 못 찾으면 null.
     */
    private static function cleanWebPage($output, array $mainSelectors, $isHidden, $absolute)
    {
        if (trim((string)$output) === '' || !class_exists('DOMDocument')) {
            return null;
        }
        $dom = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="utf-8"?>' . $output, LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        $body = $dom->getElementsByTagName('body')->item(0);
        $xpath = new \DOMXPath($dom);
        $main = null;
        foreach ($mainSelectors as $selector) {
            $found = $xpath->query($selector);
            if ($found && $found->length) {
                $main = $found->item(0);
                break;
            }
        }
        if (!$body || !$main) {
            return null;
        }
        // 앱이 폰 폭에서 좌우로 나뉜 칸을 위아래로 쌓을 때 본문을 찾는 표시
        $main->setAttribute('data-bh-main', '1');
        $css = array();
        $style = '';
        foreach (iterator_to_array($dom->getElementsByTagName('link')) as $link) {
            if (strtolower($link->getAttribute('rel')) === 'stylesheet' && strtolower($link->getAttribute('media')) !== 'print') {
                $css[call_user_func($absolute, html_entity_decode($link->getAttribute('href'), ENT_QUOTES, 'UTF-8'))] = true;
            }
        }
        foreach (iterator_to_array($dom->getElementsByTagName('style')) as $tag) {
            if ($tag->parentNode && strtolower($tag->parentNode->nodeName) === 'head') {
                $style .= $tag->textContent . "\n";
            }
        }
        foreach (array('script', 'noscript', 'form', 'link') as $name) {
            foreach (iterator_to_array($body->getElementsByTagName($name)) as $node) {
                if ($node->parentNode) {
                    $node->parentNode->removeChild($node);
                }
            }
        }
        $contains = function ($outer, $inner) {
            for ($up = $inner; $up; $up = $up->parentNode) {
                if ($up === $outer) {
                    return true;
                }
            }
            return false;
        };
        foreach (iterator_to_array($xpath->query('.//*[self::header or self::nav or self::footer or @id or @class]', $body)) as $el) {
            if (!$el->parentNode || $contains($el, $main) || $contains($main, $el)) {
                continue;
            }
            $chrome = in_array(strtolower($el->nodeName), array('header', 'nav', 'footer'), true);
            foreach (preg_split('/\s+/', strtolower($el->getAttribute('id') . ' ' . $el->getAttribute('class'))) as $name) {
                if (preg_match('/^(s_)?(header|hd|footer|ft|gnb|lnb|snb|nav|navigation|topnav|topmenu|top_menu|site-header|site-footer|site-navigation)([_-].*)?$/', $name)) {
                    $chrome = true;
                }
            }
            if ($chrome) {
                $el->parentNode->removeChild($el);
            }
        }
        foreach (iterator_to_array($body->getElementsByTagName('a')) as $a) {
            if (!$a->parentNode || !call_user_func($isHidden, call_user_func($absolute, html_entity_decode($a->getAttribute('href'), ENT_QUOTES, 'UTF-8')))) {
                continue;
            }
            $target = $a;
            for ($node = $a->parentNode; $node && $node !== $body && strtolower($node->nodeName) !== 'div'; $node = $node->parentNode) {
                if (in_array(strtolower($node->nodeName), array('li', 'tr', 'dt', 'dd'), true)) {
                    $target = $node;
                    break;
                }
            }
            if ($target->parentNode) {
                $target->parentNode->removeChild($target);
            }
        }
        $html = '';
        foreach ($body->childNodes as $child) {
            $html .= $dom->saveHTML($child);
        }
        $html = preg_replace('/<!--.*?-->/s', '', $html);
        return array(
            'content_html' => ($style !== '' ? '<style>' . $style . '</style>' : '') . $html,
            'css' => array_keys($css),
            'body_class' => trim($body->getAttribute('class')),
            'rendered' => true,
        );
    }

    private static function pageContent()
    {
        $mid = (string)BoardMoa_Api::param('mid', '');
        if ($mid === self::HOME) {
            return self::homePage();
        }
        if (strpos($mid, self::CONTENT_PREFIX) !== 0) {
            if (self::get($mid)) {
                throw new BoardMoa_Error(400, 'not_page', 'not a page', true);
            }
            throw new BoardMoa_Error(404, 'not_found', '없는 페이지입니다.');
        }
        $co = self::content(substr($mid, strlen(self::CONTENT_PREFIX)));
        if (!$co) {
            throw new BoardMoa_Error(404, 'not_found', '없는 페이지입니다.');
        }
        $html = conv_content($co['co_content'], (int)$co['co_html']);
        if (G5_IS_MOBILE && !empty($co['co_mobile_content'])) {
            $html = conv_content($co['co_mobile_content'], (int)$co['co_html']);
        }
        return array(
            'mid' => $mid,
            'title' => BoardMoa_Html::text($co['co_subject']),
            'page_type' => 'article',
            'content_html' => BoardMoa_Html::content($html),
            'web_url' => G5_BBS_URL . '/content.php?co_id=' . $co['co_id'],
        );
    }

    // ---- 링크 풀이

    public static function resolve()
    {
        $mid = (string)BoardMoa_Api::param('mid', '');
        $srl = BoardMoa_Api::intParam('document_srl');
        $path = (string)(BoardMoa_Api::param('path', '') ?: BoardMoa_Api::param('url', ''));
        if ($path === '' && $mid !== '') {
            if (strpos($mid, self::CONTENT_PREFIX) === 0 && ($co = self::content(substr($mid, strlen(self::CONTENT_PREFIX))))) {
                return array('mid' => $mid, 'module' => 'page', 'title' => BoardMoa_Html::text($co['co_subject']), 'document_srl' => null);
            }
            $b = self::get($mid);
            if ($b && self::canList($b)) {
                return array('mid' => $b['bo_table'], 'module' => 'board', 'title' => self::title($b), 'document_srl' => $srl ?: null);
            }
            // 짧은 주소의 첫 칸이 mid 로 온 경우 (/free/12 → mid=free)
            $path = '/' . $mid . ($srl ? '/' . $srl : '');
        }
        if ($path === '') {
            throw new BoardMoa_Error(404, 'not_found', '없는 페이지입니다.');
        }
        $url = preg_match('#^(https?:)?//#i', $path) ? $path : BoardMoa_Html::origin() . '/' . ltrim($path, '/');
        $found = self::locate($url);
        if (!$found) {
            throw new BoardMoa_Error(404, 'not_found', '없는 페이지입니다.');
        }
        return $found;
    }
}
